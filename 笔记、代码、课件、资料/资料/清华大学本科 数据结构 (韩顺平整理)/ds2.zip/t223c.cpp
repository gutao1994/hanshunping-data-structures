#include "iostream.h"
#include "P223.cpp"
#include "testtool.cpp"

void main(void)
{
  UFSets s(5);    
  msg("Created a Union Set: s with size 5"); 
  msg("Union 1-2,and then 2-3;should be error");
  s.Union(1,2);
  s.Union(2,3);  
  cout<<"now,the set is:"<<endl<<s;
  cout<<"1 is in "<<s.CollapsingFind(1)<<" and 2 is in "<<s.CollapsingFind(2)<<endl;
  cout<<"3 is in "<<s.CollapsingFind(3)<<" and 4 is in "<<s.CollapsingFind(4)<<endl;
  cout<<"now,the set is:"<<endl<<s;
  msg("Pack all the Set into one");
  s.Union(4,5);
  s.Union(4,1);
  cout<<"now,the set is:"<<endl<<s;   
}