#include "iostream.h"
#include "fstream.h"
#include "p284.cpp"
void main(void)
{
	cout<<endl;
	Graph g;
	fstream f;
	f.open("t284.txt",ios::in);
	f>>g;
	f.close();
	g.ShortestPath(5);
	g.BestPath(cout);
}