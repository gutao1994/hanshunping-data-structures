#include "P272.cpp"
void main(void)
{
	Graph<char,int> g(10);
cout<<endl;
  cout<<"Vertex Number:"<<g.NumberOfVertices()<<endl;
  cout<<"  Edge Number:"<<g.NumberOfEdges()<<endl;
  for (int i=0;i<g.NumberOfVertices();i++)
	  cout<<g.GetValue(i)<<" ";
  cout<<endl;
  for ( i=0; i<g.NumberOfVertices(); i++)
  {
	  
	  for (int j=0; j<g.NumberOfVertices(); j++)
	  {
		  cout<<g.GetWeight(i,j)<<" ";		  
	  }
	  cout<<endl;
  }
  cout<<endl;  
  for ( i=0; i<g.NumberOfVertices(); i++)
  {
	  cout<<g.GetValue(i)<<":";
	  int j=g.GetFirstNeighbor(i);
	  while (j!=-1)
	  {
		  cout<<g.GetValue(j)<<"("<<g.GetWeight(i,j)<<") ";
		  j=g.GetNextNeighbor(i,j);
	  }
	  cout<<endl;
  }
  cout<<endl;
  cout<<"BFS:";
  g.BFS(1);
  cout<<endl;
}