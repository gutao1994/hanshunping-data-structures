#include <iostream.h>
#include "p236.cpp"
void main (void)
{
  BST<char> t;
  int p;
  char ch;
  cout<<"Input Some char to add to the tree (/:end)";
  cin>>ch;
  while (ch!='/')
  {
    t.Insert(ch);
    t.PrintTree();
	cout<<endl;
    cin>>ch;
  }

   
  cout<<"Input Some char to check(/:end)";
  cin>>ch;
  while (ch!='/')
  {
    p=t.Find(ch);
    if (p==0) 
	{cout<<"Not found";}
	else
	{cout<<"found";}
	cout<<endl;
    cin>>ch;
  }
 
  cout<<"Input Some char to del from the tree (/:end)";
  cin>>ch;
  while (ch!='/')
  {
    t.Remove(ch);
    t.PrintTree();
	cout<<endl;
    cin>>ch;
  }
 
  char a[]={'0','1','2','3'};
  int pr[]={0,50,10,5};
  int q[]={15,10,5,5};
  t.OpticBST(pr,q,a,3);
  t.PrintTree();

}