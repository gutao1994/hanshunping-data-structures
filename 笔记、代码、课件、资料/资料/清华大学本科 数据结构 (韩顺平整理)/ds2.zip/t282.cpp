#include "IOSTREAM.H"
#include "p282.cpp"
void main(void)
{
	Graph<char,int> g(10);
	cin>>g;
	MinSpanTree gt(10);
	g.Prim(gt);
	cout<<gt;

}