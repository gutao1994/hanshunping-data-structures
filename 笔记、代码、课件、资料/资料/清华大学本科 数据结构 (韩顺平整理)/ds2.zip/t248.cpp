#include "iostream.h"
#include "p248.cpp"
void main()
{
	 AVLTree<int> avlt(-1);
	 cin>>avlt;
	 cout<<avlt;
	 
}
