#include "p297.cpp"
void main(void)
{
	Graph<char,int> g(15);
	g.CriticalPath();
}