#include "iostream.h"
#include "assert.h"
   const int NumVertices = 6;				//ͼ����󶥵����
   const int MAXINT=32767;
   class Graph {						//ͼ���ඨ��
   private:
      int n;
      int Edge[NumVertices][NumVertices];		//ͼ���ڽӾ���
      int dist[NumVertices][NumVertices];		//ͼ���ڽӾ���
      int path[NumVertices][NumVertices];		//ͼ���ڽӾ���
   public:
      void AllLengths ( );
      int choose ( const int );
      void BestPath(ostream& os);
      friend istream& operator >>(istream& strm, Graph & g);
   };

   istream& operator >>(istream& strm, Graph & g)
   {
	strm>>g.n;
	    for (int i=0;i<g.n;i++)
	    {
		    for (int j=0;j<g.n;j++)
		    {
			    strm>> (g.Edge[i][j]);
		    }

	    }
	    return strm;

   }
   void Graph::BestPath(ostream& os)
   {
	   os<<"shortest dist:"<<endl;
	   for (int i=0;i<n;i++)
	   {
	     for (int j=0;j<n;j++)
	       os<<dist[i][j]<<" ";
	     os<<endl;
	   }
	   os<<endl;
	   os<<"shortest path:"<<endl;
	   for ( i=0;i<n;i++)
	   {
	     for ( int j=0;j<n;j++)
	       os<<path[i][j]<<" ";
	     os<<endl;
	   }
	   os<<endl;
   }