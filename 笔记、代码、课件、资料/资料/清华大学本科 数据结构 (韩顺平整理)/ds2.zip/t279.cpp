#include "p279.cpp"
void main (void)
{
	Graph<char,int> g(10);
	cin>>g;
	MinSpanTree gt;
	g.Kruskal(gt);
	cout<<gt;
}