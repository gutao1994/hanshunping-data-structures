// stri.h: interface for the stri class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STRI_H__75EFDF05_B71F_11D3_B1F8_080039019863__INCLUDED_)
#define AFX_STRI_H__75EFDF05_B71F_11D3_B1F8_080039019863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "string.h"
#include "iostream.h"
#include "stdlib.h"
#include "conio.h"
#include "stdio.h"
const int maxLen=128;
class String{
public:
  String(const String &ob);
  String(const char *init);
  String();
  ~String(){delete[]ch;}
  int	Length()const{return curLen;}
  String& operator()(int pos,int len);
  int	operator ==(const String &ob)const{return strcmp(ch,ob.ch)==0;}
  int	operator !=(const String &ob)const{return strcmp(ch,ob.ch)!=0;}
  int	operator !()const{return curLen==0;}
  int  operator <(const String &ob) const{return strcmp(ch,ob.ch)<0;}
  int operator >(const String &ob) const {return strcmp(ch,ch.ob)>0;}
  String& operator =(const String &ob);
  String& operator +=(const String &ob);
  char& operator [](int i);
  int	fastFind(String &pat)const;
  int	Find(String &pat)const;
  void	replace(String &s,String &t,String &v);
  void	input(void);
  void show();
  ostream& operator << (ostream &outStream,const String st);
  istream &operator >> (istream &inStream,String st);
private:
  int	curLen;
  char	*ch;
};

#endif // !defined(AFX_STRI_H__75EFDF05_B71F_11D3_B1F8_080039019863__INCLUDED_)
