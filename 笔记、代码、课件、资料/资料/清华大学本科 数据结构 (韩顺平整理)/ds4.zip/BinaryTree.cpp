// BinaryTree.cpp: implementation of the BinaryTree class.
//
//////////////////////////////////////////////////////////////////////

#include "BinaryTree.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
template <class Type> void BinaryTree<Type>::destroy(BinTreeNode<Type> *current)
{
 if(current!=NULL)
 {
  destroy(current->leftChild);
  destroy(current->rightChild);
  delete current;
 }
}

template <class Type> BinTreeNode<Type> *BinaryTree<Type>::
	Parent(BinTreeNode<Type> *start,BinTreeNode<Type> *current)
{
 if(start==NULL)return NULL;
 if(start->leftChild==current||start->rightChild==current)return start;
 BinTreeNode<Type> *p;
 if((p=Parent(start->leftChild,current))!=NULL)return p;
 else return Parent(start->rightChild,current);
}
template <class Type> int BinTreeNode<Type>::LeafOrNull(BinTreeNode<Type> *node)
{
 if(node==NULL)return 1;
 if((node->leftChild==NULL)&&(node->rightChild==NULL))return 1;
 return 0;
}
template <class Type> void BinaryTree<Type>::Traverse(BinTreeNode<Type> *current,ostream &out)const
{
 if(current!=NULL)
 {
  out<<current->data<<' ';
  Traverse(current->leftChild,out);
  Traverse(current->rightChild,out);
 }
}
template <class Type> istream &operator>>(istream &in,BinaryTree<Type> &Tree)
{
 Type item;
 cout<<"Construct binary tree:\n";
 cout<<"Input data(end with "<<Tree.RefValue<<"):";
 in>>item;
 while(item!=Tree.RefValue)
 {
  Tree.Insert(Tree.root,item);
  cout<<"Input data(end with "<<Tree.RefValue<<"):";
  in>>item;
 }
 return in;
}
template <class Type> ostream &operator<<(ostream &out,BinaryTree<Type> &Tree)
{
 out<<"Preorder traversal of binary tree.\n";
 Tree.Traverse(Tree.root,out);
 out<<endl;
 return out;
}
/*template <class Type> int BinaryTree<Type>::Find(BinTreeNode<Type> *current,const Type &x)
{
 if(current==NULL)return 0;
 else if(x<current->data)return Find(current->leftChild,x);
  else if(x>current->data)return Find(current->rightChild,x);
   else return 1;
} */
template <class Type> void BinaryTree<Type>::Insert(BinTreeNode<Type> *&current,const Type &x)
{
 if(current==NULL)
 {
  current=new BinTreeNode<Type>;
  if(current==NULL){cout<<"Out of space"<<endl;}
  current->data=x;
 }
 else if(x<current->data)Insert(current->leftChild,x);
  else if(x>current->data)Insert(current->rightChild,x);
}
template <class Type> int BinaryTree<Type>::LeafNumber(BinTreeNode<Type> *current)
{
 if(current==NULL)return 0;
 if(current->leftChild==NULL&&current->rightChild==NULL)return 1;
 else return LeafNumber(current->leftChild)+LeafNumber(current->rightChild);
}
template <class Type> void BinaryTree<Type>::PreOrder(BinTreeNode<Type> *current)
{
 if(current!=NULL)
 {
  cout<<current->data;
  PreOrder(current->leftChild);
  PreOrder(current->rightChild);
 }
}
template <class Type> void BinaryTree<Type>::build(void)
{
 Type &item=0;
 cout<<"Construct binary tree:\n";
 cout<<"Input data(end with "<<RefValue<<"):";
 cin>>item;
 while(item!=RefValue)
 {
  Insert(root,item);
  cout<<"Input data(end with"<<RefValue<<"):";
  cin>>item;
 }
}
template <class Type> void BinaryTree<Type>::changeLR(BinTreeNode<Type> *proot)
{
 if(proot==NULL)return;
 BinTreeNode<Type> *temp;
 temp=proot->leftChild;
 proot->leftChild=proot->rightChild;
 proot->rightChild=temp;
 changeLR(proot->leftChild);
 changeLR(proot->rightChild);
}
template <class Type> void changeLR(BinaryTree<Type> const &p)
{
 BinTreeNode<Type> *proot=p.GetRoot();
 p.changeLR(proot);
/* if(!(proot->LeafOrNull(proot->leftChild)))
 {
  BinaryTree<Type> temp1;
  temp1.SetRoot(proot->leftChild);
  changeLR(temp1);
 }
 if(!(proot->LeafOrNull(proot->rightChild)))
 {
  BinaryTree<Type> temp2;
  temp2.SetRoot(proot->rightChild);
  changeLR(temp2);
 }
 BinTreeNode<Type> *temp;
 temp=proot->leftChild;
 proot->leftChild=proot->rightChild;
 proot->rightChild=temp;*/
}
