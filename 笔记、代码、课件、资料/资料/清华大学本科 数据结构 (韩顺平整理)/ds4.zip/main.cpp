#include "iostream.h"
#include "BinaryTree.cpp"
#include "BST.cpp"
#include "strin.h"

 void main( )
{
	String ch="www";
	cout<<ch<<endl;
	BST<String>   bst1(ch);

 }
