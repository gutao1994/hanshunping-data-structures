// stri.cpp: implementation of the stri class.
//
//////////////////////////////////////////////////////////////////////

#include "stri.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


String::String(const String &ob){
  ch=new char[maxLen+1];
  if(!ch){cout<<"Allocation Error\n";exit(1);}
  curLen=ob.curLen;
  strcpy(ch,ob.ch);
}
String::String(const char *init){
  ch=new char[maxLen+1];
  if(!ch){cerr<<"Allocation Error\n";exit(1);}
  curLen=strlen(init);
  strcpy(ch,init);
}
String::String(){
  ch=new char[maxLen+1];
  if(!ch){cout<<"Allocation Error\n";exit(1);}
  curLen=0;
  ch[0]='\0';
}
String &String::operator()(int pos,int len){
  String *temp=new String;
  if(pos<0||pos+len-1>=maxLen||len<0){
   temp->curLen=0;temp->ch[0]='\0';
  }
  else{
       if(pos+len-1>=curLen)len=curLen-pos;
	temp->curLen=len;
	for(int i=0,j=pos;i<len;i++,j++)
	 temp->ch[i]=ch[j];
	temp->ch[len]='\0';
	}
  return *temp;
}
String &String::operator =(const String &ob){
 if(&ob!=this){
  delete []ch;
  ch=new char[maxLen+1];
  if(!ch){cerr<<"Out of memory!\n";exit(1);}
  curLen=ob.curLen;
  strcpy(ch,ob.ch);
 }
 else cout<<"Attempted assignment of a String to itself!\n";
 return *this;
}
String &String::operator +=(const String &ob){
 char *temp=ch;
 curLen+=ob.curLen;
 ch=new char[maxLen+1];
 if(!ch){cerr<<"Out of memory!\n";exit(1);}
 strcpy(ch,temp);
 strcat(ch,ob.ch);
 delete []temp;
 return *this;
}
char &String::operator [](int i){
 if(i<0&&i>=curLen){cout<<"Out of boundary!\n";exit(1);}
 return ch[i];
}
int String::fastFind(String &pat)const{
 int posP=0,posT=0;
 int lengthP=pat.curLen,lengthT=curLen;
 while(posP<lengthP&&posT<lengthT)
  if(pat.ch[posP]==ch[posT]){
	posP++;posT++;
  }
  else if(posP==0)posT++;
       else posP=pat.ch[posP-1]+1;
  if(posP<lengthP)return -1;
  else return posT-lengthP;
}
int String::Find(String &pat)const{
 char *p=pat.ch,*s=ch;
 int i=0;
 if(*p&&*s)
  while(i<=curLen-pat.curLen)
   if(*p++==*s++){
    if(!*p)return i;
   }
 else{i++;s=ch+i;p=pat.ch;}
 return -1;
}
void String::replace(String &s,String &t,String &v)
{
 int i;
 cprintf("s:");
 for(i=0;i<=s.curLen;i++)
  cout<<s.ch[i];
 cout<<endl;
 if(t.curLen>s.curLen)
  cout<<"No replaced.";
 int num,sEnd=0,replaced=0;
 String temp=s,stemp;
 while(!sEnd)
 {
  num=temp.Find(t);
  if(num==-1)
  {
   if(replaced)
    stemp+=temp;
   else cout<<"No replaced."<<endl;
   sEnd=1;
  }
  else
  {
   cout<<num<<endl;
   replaced=1;
   stemp+=temp(0,num);
   stemp+=v;
   num+=t.curLen;
   if(num<=temp.curLen-t.curLen+1)
    temp=temp(num,temp.curLen);
   else sEnd=1;
  }
 }
 if(replaced)
  s=stemp;
 cprintf("s:");
 for(i=0;i<=s.curLen;i++)
  cout<<s.ch[i];
 cout<<endl;
}
void String::input(void)
{
 ch=new char[maxLen+1];
 int i=0;
 char c=getchar();
 while(c!='\n')
 {
  ch[i]=c;
  i++;
  c=getchar();
 }
 curLen=i-1;
}
void String::show()
{
	cout<<ch<<endl;
}
ostream &operator<<(ostream &outStream,const String st)
{
	outStream<<"The String is";
    for(int i=0;i<st.Length();i++)
		outStream<<st.[i];
    outStream<<endl;
    return OutStream; 
}

instream &operator>>(istream &inStream,String st)
{
	cout<<"Enter The String"<<endl;
    int i=0;
	do{
		inStream>>st.[i];
		i++;}
	while(i<maxLen&&st.[i]!='/n') ;
	return inStream;
}
