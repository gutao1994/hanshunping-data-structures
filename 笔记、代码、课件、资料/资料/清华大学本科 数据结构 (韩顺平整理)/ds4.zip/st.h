#include "string.h"
#include "iostream.h"
#include "stdlib.h"
#include "conio.h"
#include "stdio.h"

const int maxLen=128;

class String{
public:
  String(const String &ob);
  String(const char *init);
  String();
  ~String(){delete[]ch;}
  int	Length()const{return curLen;}
  String& operator()(int pos,int len);
  int	operator ==(const String &ob)const{return strcmp(ch,ob.ch)==0;}
  int	operator !=(const String &ob)const{return strcmp(ch,ob.ch)!=0;}
  int	operator !()const{return curLen==0;}
  String& operator =(const String &ob);
  String& operator +=(const String &ob);
  int  operator <(const String &ob) const{return strcmp(ch,ob.ch)<0;)
  int operator >(const String &ob) const {return strcmp(ch,ch.ob)>0;}
  char& operator [](int i);
  int	fastFind(String &pat)const;
  int	Find(String &pat)const;
  void	replace(String &s,String &t,String &v);
  void	input(void);
  void show();
//friend ostream &operator<<(ostream& outStream,const  String st);
//friend istream  &operator>>(istream& inStream,String st); 
private:
  int	curLen;
  char	*ch;
};