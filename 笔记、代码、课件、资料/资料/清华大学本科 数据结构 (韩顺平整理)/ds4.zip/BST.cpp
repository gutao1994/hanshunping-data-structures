// BST.cpp: implementation of the BST class.
//
//////////////////////////////////////////////////////////////////////

#include "BST.h"
#include "stdlib.h" 
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

template <class Type> BstNode<Type> *BST<Type>::Find(const Type &x,BstNode<Type> *ptr) const
{
	if(ptr==NULL) return NULL;
	else if(x<ptr->data) return Find(x,ptr->leftChild);
		else if(x>ptr->data) return Find(x,ptr->rightChild);
			else return ptr;
}

template <class Type> void BST<Type>::Insert(const Type &x,BstNode<Type>  *&ptr)
{
	if(ptr==NULL) {
		ptr=new BstNode<Type>(x);
		if(ptr==NULL){cerr<<"Out of space"<<endl;exit(1);}
	}
	else if(x<ptr->data) Insert(x,ptr->leftChild);
		else if(x>ptr->data)Insert(x,ptr->rightChild);
}

template <class Type> BST<Type>::BST(Type value)
{
	Type x;root=NULL;RefValue=value;
	cin>>x;
	while(x!=RefValue){
		Insert(x,root);cin>>x;
	}
}

template <class Type> void BST<Type>::Remove(const Type &x,BstNode<Type> *&ptr)
{
	BstNode<Type> * temp;
	if(ptr!=NULL)
		if(x<ptr->data) Remove(x,ptr->leftChild);
		else if(x>ptr->data) Remove(x,ptr->rightChild);
		else if(ptr->leftChild!=NULL&&ptr->rightChild!=NULL){
			temp=Min(ptr->rightChild);
			ptr->data=temp->data;
			Remove(ptr->data,ptr->rightChild);
		}
		else{
			temp=ptr;
			if(ptr->leftChild==NULL) ptr=ptr->rightChild;
			else if(ptr->rightChild==NULL) ptr=ptr->leftChild;
			delete temp;
		}
}

//template<class Type> void BST<Type>::Setup(

