// BinaryTree.h: interface for the BinaryTree class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BINARYTREE_H__7B79F3A1_B613_11D3_B1F8_080039019863__INCLUDED_)
#define AFX_BINARYTREE_H__7B79F3A1_B613_11D3_B1F8_080039019863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "iostream.h"
template <class Type> class BinaryTree;
template <class Type> class BinTreeNode
{
 friend class BinaryTree;
 friend void changeLR(BinaryTree<Type> const &p);
 public:
  BinTreeNode():leftChild(NULL),rightChild(NULL){}
  BinTreeNode(Type item,BinTreeNode<Type> *left=NULL,
	BinTreeNode<Type> *right=NULL):data(item),leftChild(left),rightChild(right){}
  //Type &GetData(void)const{return data;}
  BinTreeNode<Type> *GetLeft()const{return leftChild;}
  BinTreeNode<Type> *GetRight()const{return rightChild;}
  void SetData(const Type &item){data=item;}
  void SetLeft(BinTreeNode<Type> *L){leftChild=L;}
  void SetRight(BinTreeNode<Type> *R){rightChild=R;}
  int LeafOrNull(BinTreeNode<Type> *node);
// private:
  BinTreeNode<Type> *leftChild,*rightChild;
  Type data;
};
template <class Type> class BinaryTree
{
 friend void changeLR(BinaryTree<Type> const &p);
 public:
  BinaryTree():root(NULL){}
  BinaryTree(Type value):RefValue(value),root(NULL){}
  virtual ~BinaryTree(){destroy(root);}
  virtual int IsEmpty(void){return root==NULL?1:0;}
  virtual BinTreeNode<Type> *Parent(BinTreeNode<Type> *current)
  {return root==NULL||root==current?NULL:Parent(root,current);}
  virtual BinTreeNode<Type> *LeftChild(BinTreeNode<Type> *current)
  {return root!=NULL?current->leftChild:NULL;}
  virtual BinTreeNode<Type> *RightChild(BinTreeNode<Type> *current)
  {return root!=NULL?current->rightChild:NULL;}
  //virtual int Insert(const Type &item);
  //virtual int Find(const Type &item)const;
  BinTreeNode<Type> *GetRoot(void)const{return root;}
  void SetRoot(BinTreeNode<Type> *proot){root=proot;}
  void PreOrder(BinTreeNode<Type> *current);
  int LeafNumber(BinTreeNode<Type> *current);
  void build(void);
  void changeLR(BinTreeNode<Type> *proot);
  friend istream &operator>>(istream &in,BinaryTree<Type> &Tree);
  friend ostream &operator<<(ostream &out,BinaryTree<Type> &Tree);
 private:
  BinTreeNode<Type> *root;
  Type RefValue;
  BinTreeNode<Type> *Parent(BinTreeNode<Type> *start,BinTreeNode<Type> *curent);
  void Insert(BinTreeNode<Type> *&current,const Type &item);
  void Traverse(BinTreeNode<Type> *current,ostream &out)const;
  //int Find(BinTreeNode<Type> *current,const Type &item)const;
  void destroy(BinTreeNode<Type> *current);
};

#endif // !defined(AFX_BINARYTREE_H__7B79F3A1_B613_11D3_B1F8_080039019863__INCLUDED_)
