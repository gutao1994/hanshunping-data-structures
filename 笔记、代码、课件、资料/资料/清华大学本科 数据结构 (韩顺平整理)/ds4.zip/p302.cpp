		//#ifndef DATA:LIST_H
		//#define DATALIST_H
		#include <iostream.h>
		#define DefaultSize  100								//���ݱ���ȱʡ��С
		template<class Type> struct Element{									//��Ԫ�صĶ���
			 Type key;										//�ؼ���
			 //field otherdata;									//������
		};

		template <class Type> class DataList {
		//��˳������洢�������Ԫ�ء���ЩԪ�ص�������Type ��
		friend istream& operator >> ( istream& , DataList<Type>& );
		friend ostream& operator << ( ostream& , DataList<Type> );
		friend void InsertionSort ( DataList<Type> & );
		friend void Insert ( DataList<Type> &, int );
		friend void BinaryInsertSort ( DataList<Type> & );
		friend void BinaryInsert ( DataList<Type> &, int );
		friend void ShellSort ( DataList<Type> & );
		friend void ShellInsert ( DataList<Type> & , const int );
		friend void BubbleSort ( DataList<Type> & );
		friend void BubbleExchange ( DataList<Type> & , const int, int & );
		friend int Partition ( DataList<Type> &, const int , const int );
		friend void SelectSort ( DataList<Type> & );
		friend void SelectExchange ( DataList<Type> & , const int );
		friend void MergeSort ( DataList<Type> & );
		friend void MergePass ( DataList<Type> &, DataList<Type> &, int );
		friend void merge ( DataList<Type> &, DataList<Type> &, int, int, int );

		private:
		   Element<Type> * Vector;								//�洢������Ԫ�ص�����
		   int MaxSize;										//������С
		   int CurrentSize;										//��ǰ������Ԫ�ظ���
		public:
		   DataList ( int MaxSz = DefaultSize ) : MaxSize ( MaxSz),CurrentSize (0) { Vector = new Element<Type>[MaxSize] ; }
					//���캯��
		   void Swap ( int x, int y )				//��������Ԫ��
			{ Element<Type> temp = Vector[x];  Vector[x] = Vector[y];  Vector[y] = temp; };
		   int Add ( Type & );
		};
//		#endif


		template <class Type> int DataList<Type>::Add ( Type & x ) {
		    if ( CurrentSize == MaxSize ) return 0;
		    Vector[CurrentSize++].key = x ;
		    return 1;
		}

		template <class Type> istream& operator >> ( istream& is, DataList<Type>& list ) {
		    cout << "how many numbers in datalist? " ;
		    int n;
		    is >> n;
		    while ( n > list.MaxSize ) {
			cout << "too many, please try again: ";
			is >> n;
		    }
		    list.CurrentSize = n;
		    for ( int i = 0; i < n; i++ )
			is >> list.Vector[i].key;
		    return is;
		}

		template <class Type> ostream& operator << ( ostream& os, DataList<Type> list ) {
		    for ( int i = 0; i < list.CurrentSize; i++ ) os << list.Vector[i].key << ' ';
		    return os;
		}
