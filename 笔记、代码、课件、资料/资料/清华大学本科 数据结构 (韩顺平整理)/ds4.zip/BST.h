// BST.h: interface for the BST class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BST_H__7B79F3A0_B613_11D3_B1F8_080039019863__INCLUDED_)
#define AFX_BST_H__7B79F3A0_B613_11D3_B1F8_080039019863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "iostream.h"
#include "BInaryTree.h"
template  <class Type> class BST;
template <class Type> class BstNode:public BinTreeNode<Type>{
  friend  class BST<Type>;
  public :
	  BstNode():leftChild(NULL),rightChild(NULL){}
	  BstNode(const Type d):data(d),leftChild(NULL),rightChild(NULL){}
	/*BstNode(const Type d=0,BstNode * L=NULL,BstNode * R=NULL)
		  :data(d),leftChild(L),rightChild(R){}*/
	  ~BstNode(){}
  protected:
	  Type data;
	  BstNode<Type> * leftChild,* rightChild;
};

template <class Type> class BST:BinaryTree<Type>{
	public:
		BST():root(NULL){}
		BST(Type value);//:RefValue(value),root(NULL){}
		~BST(){}//MakeEmpty(root);}
		const BST &operator =(const BST & Value);
		//void MakeEmpty(){MakeEmpty(root);root=NULL;}
		void PrintTree() const{PrintTree(root):}
		int Find(const Type& x) const {return Find(x,root)==NULL;}
		Type Min();
		Type Max();
		void Insert(const Type &x){Insert(x,root);}
		void Remove(const Type &x);//{Remove(x,root);}
		BstNode <Type> * Split(Type i,BST <Type> & B,Type &x,BST <Type> &C);
	private:
		BstNode<Type> * root;
		Type RefValue;
		BstNode<Type> * lastfound;
		//void MakeEmpty(BstNode<Type> * &ptr);
		void Insert(const Type &x,BstNode<Type> *&ptr);
		void Remove(const Type &x,BstNode<Type> *&ptr);
		void PrintTree(BstNode<Type> *ptr) const;
		BstNode<Type> * Copy(const BstNode<Type> * ptr);
		BstNode<Type> *  Find(const  Type &x,BstNode<Type> *ptr) const;
		BstNode<Type> *Min(BstNode<Type> * ptr) const;
		BstNode<Type> *Max(BstNode<Type> *ptr) const;
//		friend class BSTIterator<Type>;
};




#endif // !defined(AFX_BST_H__7B79F3A0_B613_11D3_B1F8_080039019863__INCLUDED_)


