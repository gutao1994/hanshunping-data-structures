// strin.h: interface for the strin class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STRIN_H__BD21C8A0_B79E_11D3_B1F8_080039019863__INCLUDED_)
#define AFX_STRIN_H__BD21C8A0_B79E_11D3_B1F8_080039019863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "string.h"
#include "iostream.h"
#include "stdlib.h"
#include "conio.h"
#include "stdio.h"
const int maxLen=128;
class String{
public:
  String(const String &ob);
  String(const char *init);
  String();
  ~String(){delete[]ch;}
  int	Length()const{return curLen;}
  String& operator()(int pos,int len);
  int	operator ==(const String &ob)const{return strcmp(ch,ob.ch)==0;}
  int	operator !=(const String &ob)const{return strcmp(ch,ob.ch)!=0;}
  int	operator !()const{return curLen==0;}
  int  operator <(const String &ob) const{return strcmp(ch,ob.ch)<0;}
  int operator >(const String &ob) const {return strcmp(ch,ob.ch)>0;}
  String& operator =(const String &ob);
  String& operator +=(const String &ob);
  char& operator [](int i);
  int	fastFind(String &pat)const;
  int	Find(String &pat)const;
  void	replace(String &s,String &t,String &v);
  void	input(void);
  void show();
  friend ostream &operator<<(ostream& outStream,String st);
  friend istream  &operator>>(istream& inStream,String &st); 
private:
  int	curLen;
  char	*ch;
};

#endif // !defined(AFX_STRIN_H__BD21C8A0_B79E_11D3_B1F8_080039019863__INCLUDED_)
