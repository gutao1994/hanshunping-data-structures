#include "iostream.h"
class List;
class ListNode{
	friend class List;
private:
	int data;
	ListNode* fo,*la;
public:
	ListNode(int item):data(item),fo(NULL),la(NULL){};
	
};
//The defination of class List:
class List{
private:
	ListNode *head,*current,*last;
public:
	List(ListNode* p){head=last=current=p;}
	void Insert(ListNode* node);
	void PrintAll();
};

//������Insert()��ʵ��:
void List::Insert(ListNode* node){
	//ListNode* temp;
//	node=new ListNode(item);
	last->la=node;
	node->fo=last;
	last=node;
	}
//������PrintAll()��ʵ��:
void List::PrintAll(){
	current=head;
	cout<<endl;
	while(current!=NULL){
		cout<<current->data<<"***";
	}
	cout<<"finished!"<<endl;
}

//main():
void main(){
	List *mainlist;
	ListNode* node;
	int a;
	cout<<"input the first number:"<<endl;
	cin>>a;
	node=new ListNode(a);
	mainlist=new List(node);
	for(int i=1;i<=3;i++){
		cout<<"input the "<<i+1<<"nd number:"<<endl;
		cin>>a;
		node=new ListNode(a);
		mainlist->Insert(node);

	}

	mainlist->PrintAll();
}
	
