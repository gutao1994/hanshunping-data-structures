
#include "iostream.h"



class BinaryTree;

class BinTreeNode{
friend class BinaryTree;
public:
	BinTreeNode():leftChild(NULL),rightChild(NULL){}
	BinTreeNode(char item,BinTreeNode*left=NULL,
		BinTreeNode*right=NULL):data(item),leftChild(left),
		rightChild(right){}
	BinTreeNode *GetNode(char &item){
		BinTreeNode *temp=new BinTreeNode(item);
		return temp;
	}
	char GetData()const{return data;}
    BinTreeNode*GetLeft()const{return leftChild;}
	BinTreeNode*GetRight()const{return rightChild;}
	void SetData(const char& item){data=item;}
	void SetLeft(BinTreeNode*L){leftChild=L;}
	void SetRight(BinTreeNode*R){rightChild=R;}
	void operator=(BinTreeNode*Right);

private:
	BinTreeNode *leftChild,*rightChild;
	char data;
};

class BinaryTree{
public:
	BinaryTree():root(NULL){};
	BinaryTree(char value):RefValue(value){root=new BinTreeNode(value);}
	virtual ~BinaryTree(){destroy(root);}
	virtual int IsEmpty(){return root==NULL?1:0;}
	virtual BinTreeNode*Parent(BinTreeNode*current){
		return root==NULL||root==current?NULL:Parent(root,current);}
    virtual BinTreeNode*LeftChild(BinTreeNode*current){
		return root!=NULL?current->leftChild:NULL;}
    virtual BinTreeNode*RightChild(BinTreeNode*current){
		return root!=NULL?current->rightChild:NULL;}
    const BinTreeNode*GetRoot()const{return root;}
	void  Construct(char *arr,int n);
	void BldBst(char *arr,int n,float*p,float*q){BldBst(root,arr,n,p,q);}
private:
	BinTreeNode *root;
	char RefValue;
	BinTreeNode*Parent(BinTreeNode*start,BinTreeNode*current);
	void Traverse(BinTreeNode*current,ostream &out)const;
	void destroy(BinTreeNode*current);
	void ExChild(BinTreeNode*current);
	void BldBst(BinTreeNode*current,char *arr,int n,float *p,float*q);
};

