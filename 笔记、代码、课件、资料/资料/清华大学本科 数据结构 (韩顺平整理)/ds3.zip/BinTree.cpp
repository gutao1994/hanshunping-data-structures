#include "BinTree.h"

template <class Type>
void BinTree<Type>::destroy(BinTreeNode<Type> *current)
{//˽�к���
	if (current!=NULL){
		destroy(current->leftChild);
		destroy(current->rightChild);
		delete current;
	}
}

template <class Type>
BinTreeNode<Type> *BinTree<Type>::Parent(BinTreeNode<Type> *start,BinTreeNode<Type> *current)
{//˽�к���
	if (start==NULL) return NULL;
	if (start->leftChild==current||start->rightChild==current) return start;
    BinTreeNode<Type> *p;
	if ((p=Parent(start->leftChild,current))!=NULL) return p;
	else return Parent(start->rightChild,current);
}

template <class Type>
void BinTree<Type>::Traverse(BinTreeNode<Type> *current,ostream &out)const
{//˽�к���
    if (current!=NULL)
	{
		out<<current->data<<' ';
		Traverse(current->leftChild,out);
        Traverse(current->rightChild,out);
	}
}

template <class Type>
istream &operator>>(istream &in,BinTree<Type> &Tree)
{//���ز��������벢����һ�ö�����Tree,in������������
	Type item;
	cout<<"Construct binary tree!";
	cout<<"Input data (end with"<<Tree.RefValue<<")";
	in>>item;
	while (item!=Tree.RefValue)
	{
		Tree.Insert(item);
		cout<<"Input data (end with"<<Tree.RefValue<<")";
		in>>item;
	}
	return in;
}

template <class Type>		 
ostream &operator<<(ostream &out,BinTree<Type> &Tree)
{//���ز��������һ�ö�����Tree,out�����������
	out<<"Preorder Traversal of binary tree :"<<endl;
	Tree.Traverse(Tree.root,out);
	out<<endl;
	return out;
}

//===================Add Funtion==============================
template <class Type>
void BinTree<Type>::SetUpTree(BinTreeNode<Type> *current,Type *T,int i)
{
	if (i<=T[0])
	{
		if (i==1) root=current;
		current->data=T[i];
		
		if ((T[2*i]=='*')||(2*i>T[0])) current->leftChild=NULL;
		    else SetUpTree(current->leftChild=new BinTreeNode<Type>,T,2*i);
		
		if ((T[2*i+1]=='*')||((2*i+1)>T[0])) current->rightChild=NULL;
		    else SetUpTree(current->rightChild=new BinTreeNode<Type>,T,2*i+1);
	}

}