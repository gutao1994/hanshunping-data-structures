#include<iostream.h>
template<class Type>class DblList;
template<class Type>class DblNode{//double direct list node class
	friend class DblList<Type>;
	private:
		Type data;//data field
		DblNode<Type> *lLink,*rLink;//link pointer
	public:
		DblNode(Type value,DblNode<Type> *left,DblNode *right):data(value),lLink(left),rLink(right){}
        DblNode(Type value):data(value),lLink(NULL),rLink(NULL){}
		DblNode<Type>*Next(){return rLink;}
		DblNode<Type>*Prior(){return lLink;}
		Type GetValue(){return data;}
};
template<class Type>class DblList{//double direct list class definition
	public:
		DblList(Type uniqueVal);
		~DblList();
		void MakeEmpty();//set empty
		int Length()const;//get the length
		int IsEmpty(){return first->rLink==first;}//wether is it empty
		int Find(const Type&target);//find an element
		Type GetData()const;//return current data
		void Firster(){current=first;}
		DblNode<Type>*GetHead(){return first;}
		DblNode<Type>*Current(){return current;}//get current pointer
		int First();//put the pointer to the first 
		int Next();//pointer moves to next location
		int Prior();//pointer moves to  prior location
		void Insert(const Type&value);//Insert node with value 
		Type Remove();//remove current node
		void Disply();//show the data of the DblList
	private:
		DblNode<Type>*first,*current;
};
template<class Type>void DblList<Type>::MakeEmpty(){
		while(current!=NULL)Remove();
}
template<class Type>DblList<Type>::~DblList(){MakeEmpty();delete first;}
template<class Type>DblList<Type>::DblList(Type uniqueVal){
	first=new DblNode<Type>(uniqueVal);
	first->rLink=first->lLink=first;
	current=NULL;
}
template<class Type>int DblList<Type>::Length()const{
	DblNode<Type>*p=first->rLink;
	int count=0;
	while(p!=first){p=p->rLink;count++;}
	return count;
}
template<class Type>int DblList<Type>::Find(const Type &target){
	int count=1;
	DblNode<Type>*p=first->rLink;
	while(p!=first&&p->data!=target){p=p->rLink;count++;}
	if(p!=first){current=p;return count;}
	return 0;
}
template<class Type>Type DblList<Type>::GetData()const{
	int a;
	if(first->rLink==first){
		cout<<"no data in list,illegal operate\npress 0 and ENTER\n";
		cin>>a;
		return NULL;
	}
	else return current->data;
}
template<class Type>int DblList<Type>::First(){
	if(!IsEmpty()){current=first->rLink;return 1;}
	current=NULL;return 0;
}
template<class Type>int DblList<Type>::Next(){
	if(IsEmpty()){return 0;}
	current=current->rLink;
	if(current==first)current=first->rLink;
	return 1;
}
template<class Type>int DblList<Type>::Prior(){
	if(IsEmpty){return 0;}
	current=current->lLink; 
	if(current==first)current=first->lLink;
	return 1;
}
template<class Type>void DblList<Type>::Insert(const Type &value){
	if(IsEmpty())
		current=first->rLink=new DblNode<Type>(value,first,first);
	else{
		current=first->rLink;
		while(current!=first&&current->data<value)
			current=current->rLink;
		if(current->data==value){
			cout<<endl<<"The key-word_"<<value<<" has existed!"<<endl;
			return;
		}
		current=current->lLink;
        current->rLink=new DblNode<Type>(value,current,current->rLink);
		current=current->rLink;
	}
	current->rLink->lLink=current;
}
template<class Type>Type DblList<Type>::Remove(){
	Type value;
	if(current!=NULL){
		DblNode<Type> *temp=current;
		current=current->rLink;
		current->lLink=temp->lLink;
		temp->lLink->rLink=current;
		value=temp->data;
		delete temp;
		if(current==first)
			if(IsEmpty())current=NULL;
			else current=current->rLink;
	}
	return value;
}
template<class Type>void DblList<Type>::Disply(){
	if(current!=NULL){
		DblNode<Type>*p=current;
		current=first->rLink;
		while(current!=first){
			cout<<current->data<<" ";
			current=current->rLink;
		}
		cout<<endl;
		current=p;
	}
}
//here is the homework,search the keyword and locate it with p
void search(DblList<int>&dlist,DblNode<int>*&p,int key){
    if(dlist.IsEmpty()){cout<<"Search failed!\n";return;}
	//list is empty ,cannot search
	DblNode<int>*head=dlist.GetHead();
	if(p==NULL)p=head->Next();//if p is NULL,search from head
	
	if(key<p->GetValue()){//key is smaller,search the front
        while(p!=head&&p->GetValue()>key)p=p->Prior();
		//search until find the keyword
		if(p->GetValue()<key||p==head){
			//the keyword doesn't exist
			cout<<"Search of keyword "<<key<<" failed!"<<endl;
			p=NULL;
		}
	}
	else {//key is larger than p->data,so search the back
		while(p!=head&&p->GetValue()<key)p=p->Next();
		//search until find the keyword
		if(p->GetValue()>key||p==head){
			//the keyword doesn't exist
			cout<<"Search of keyword "<<key<<" failed!"<<endl;
			p=NULL;
		}
	}
}
void main()
{
	DblList<int> dlist(-100);
	int array[10]={5,6,4,8,0,9,2,1,3,7};
	for(int i=0;i<10;i++)//insert to construct a DblList
		dlist.Insert(array[i]);
	cout<<"Construct the DList with element 5,6,4,8,0,9,5,1,3,7";
	cout<<endl;
	dlist.Disply();//show the sorting list 
	cout<<endl;

	DblNode<int>*p=NULL;
	cout<<"search 2 in list."<<endl;
	search(dlist,p,2);//search keyword 2 in dlist,p locate it
	if(p!=NULL)cout<<"data of pointer p:"<<p->GetValue()<<endl;
	else cout<<"pointer is NULL"<<endl;
	cout<<"search 4 in list."<<endl;
	search(dlist,p,4);//search keyword 4 
	if(p!=NULL)cout<<"data of pointer p:"<<p->GetValue()<<endl;
	else cout<<"pointer is NULL"<<endl;
	cout<<"search 10 in list."<<endl;
	search(dlist,p,10);//search keyword 10,it doesn't exist
	if(p!=NULL)cout<<"data of pointer p:"<<p->GetValue()<<endl;
	else cout<<"pointer is NULL"<<endl;
}


