#include <iostream.h>
#include "T_List.h"

template <class Type> 
ListNode<Type>::ListNode():link(NULL){}

template <class Type> 
ListNode<Type>::ListNode(Type &item):data(item),link(NULL){}

template <class Type> 
void ListNode<Type>::InsertAfter(ListNode<Type> *p)
{
	p->link=link;  link=p;
}

template <class Type> 
ListNode<Type> *ListNode<Type>::GetTheNode(const Type &item)
{
	ListNode<Type> *newnode=new ListNode<Type>(item);
	return newnode;
}

template <class Type> 
ListNode<Type> *ListNode<Type>::RemoveAfter()
{
	ListNode<Type> *tempptr=link;
	if (link==NULL) return NULL;
	link=tempptr->link;
	return tempptr;
}

template <class Type> 
List<Type>::~List()
{
	MakeEmpty(); 
	delete first; 
	first=last=NULL;
}

template <class Type> 
void List<Type>::MakeEmpty()
{
	ListNode<Type> *q;
	while (first->link!=NULL)
	{
		q=first->link; 
		first->link=q->link;
		delete q;
	}
	last=first;
}

template <class Type> 
int List<Type>::Length() const
{
	ListNode<Type> *p=first->link; 
	int count=0;
	while (p!=NULL) 
	{
		p=p->link; count++;
	}
	return count;
}

template <class Type> 
ListNode<Type> *List<Type>::vFind(Type value)
{
	ListNode<Type> *p=first->link;
	while ((p!=NULL)&&(p->data!=value)) p->link;
	return p;
}

template <class Type> 
ListNode<Type> *List<Type>::iFind(int i)
{
	if (i<-1) return NULL;
	if (i==-1) return first;
	ListNode<Type> *p=first->link;
	int j=0;
	while ((p!=NULL)&&(j<i)) { p=p->link; j=j++;}
	return p;
}

template <class Type> 
int List<Type>::Insert(Type value,int i)
{
	ListNode<Type> *p=iFind(i-1);
	if (p==NULL) return 0;
	ListNode<Type> *newnode=GetTheNode(value);
    /*newnode=new(ListNode<Type>);
	newnode->data=value;
	newnode->link=NULL;*/
	if (p->link==NULL) last=newnode;
	p->link=newnode;
	return 1;
}

template <class Type> 
Type *List<Type>::Remove(int i)
{
	ListNode<Type> *p=iFind(i-1), *q;
	if ((p==NULL)||(p->link==NULL)) retrun NULL;
	q=p->link;
	p->link=q->link;
	Type value=q->data;
	if (q=last) last=p;
	delete q;
	return &value;
}

template <class Type> 
Type List<Type>::Get(int i)
{
	ListNode<Type> *p=iFind(i);
	if ((p==NULL)||(first->link==NULL)) return NULL;
	                      else return p->data;
}

template <class Type>
void List<Type>::TMerge(List<Type> &listb)
{  //������listb�͵�ǰ�����ϲ�����ǰ������listb�����ǵݼ�
   //�ϲ��󰴷ǵ���˳��������ֵͬ���ϲ���ɾ������listb
	ListNode<Type> *p=first->link,*q=listb.first;
	q=q->link;
	ListNode<Type> *hap,*r;
	first->link=NULL;  
	hap=first;
	
	while (p!=NULL&&q!=NULL)
	{
		if (p->data>q->data)
		{ r=p;  p=p->link; }
		else
		{ r=q;  q=q->link; }
		r->link=hap->link; 
		hap->link=r;
	}
    if (p!=NULL) while (p!=NULL) {r=p; p=p->link; r->link=hap->link; hap->link=r;}
    if (q!=NULL) while (q!=NULL) {r=q; q=q->link; r->link=hap->link; hap->link=r;}
    p=first->link;
	while(p->link!=NULL) p=p->link;
	last=p;
	
	q=listb.first; q->link=NULL;
	listb.last=listb.first;
	
	
}
