#include <iostream.h>
#include <stdlib.h>
int maxnum(int a[],int n){
	if(n==1) return a[0];
	int maxn=maxnum(a,n-1);
	if(a[n-1]>maxn) return a[n-1];
	else return maxn;
}
int sum(int a[],int n){
	if(n==1) return a[0];
	else return sum(a,n-1)+a[n-1];
}
int average(int a[],int n){
	return sum(a,n)/n;
}
void main(){
	int *a,n;char c;
	cout<<"input the array size n(>0):";
	cin>>n;
	if(n<0){
		cerr<<"n>0"<<endl;
		exit(1);
	}a=new int[n];
	if(a==0){
		cerr<<"memory error"<<endl;
		exit(1);
	}cout<<"input the data"<<endl;
	for(int i=0;i<n;i++){
		cout<<"input the data of array["<<i<<"]: ";
		cin>>a[i];
	}cout<<"0 for exit"<<endl;
	cout<<"1 for get the max number"<<endl;
	cout<<"2 for get the sum of the array"<<endl;
	cout<<"3 for get the average of all the data"<<endl;
	cout<<"input the choice:";
	cin>>c;
	while(c!='0'){
		switch(c){
		case('1'):cout<<endl<<"the max number is: "<<maxnum(a,n)<<endl;break;
		case('2'):cout<<endl<<"the sum is: "<<sum(a,n)<<endl;break;
		case('3'):cout<<endl<<"the average is: "<<average(a,n)<<endl;
		}cout<<"0 for exit"<<endl;
		cout<<"1 for get the max number"<<endl;
		cout<<"2 for get the sum of the array"<<endl;
		cout<<"3 for get the average of all the data"<<endl;
		cout<<"input the choice:";
		cin>>c;
	}delete[] a;
}
