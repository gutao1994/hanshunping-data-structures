//�������������ඨ��;
#include "iostream.h"
#include "stdlib.h"
//
class Tree;
class TreeNode{
	friend class Tree;
public:
	TreeNode(int item,TreeNode* le=NULL,TreeNode* ri=NULL):\
		data(item),le(le),ri(le){}
	~TreeNode();
	TreeNode *le,*ri;
	void Locate(int c,TreeNode* temp);
private:
	int data;
};

//�����������ඨ��;
class Tree{
public:
	Tree(TreeNode *p):root(p){}
	~Tree();
	TreeNode * GetPar(int c);
	void InOrder(int& leaf,TreeNode* current);
	TreeNode* GetRoot(){return root;}
	int GetHead(){return root->data;}
	void Tranvers(TreeNode* current);
private:
	TreeNode *root;
};
//������GetPar������ʵ��;
TreeNode* Tree::GetPar(int c){
	int par=c/2;
	TreeNode *Add;				
	if(c==1) {cout<<"error!"<<endl;return NULL;}
	if(c/2==1) return root;
	Add=GetPar(par);
	Add=(par%2==0)?Add->le:Add->ri;
	return Add;
}

//locate():
void TreeNode::Locate(int c,TreeNode* temp){
	if(c%2==0)    le=temp;
	if(c%2==1)    ri=temp;
}
//�������������;
void Tree::InOrder(int & leaf,TreeNode* current){
    if(current!=NULL){
		InOrder(leaf,current->le);
		if((current->le==NULL)&&(current->ri==NULL)) 
		  	leaf++;
		InOrder(leaf,current->ri);
	}
}
//������˫�����;
void Tree::DouOrder(TreeNode* current){
    if(current!=NULL){
		InOrder(leaf,current->le);
		cout<<current->data<<"------";
		InOrder(leaf,current->ri);
		cout<<current->data<<"-------";

	}
}
//�����Ƿ�ת����;
void Tree::Tranvers(TreeNode *current){
	TreeNode* p;
	if(current!=NULL){
		Tranvers(current->le);
			p=current->le;current->le=current->ri;current->ri=p;
		Tranvers(current->ri);
	}
}

//������main����;
void main(){
	int count=1,leaf=0;
	TreeNode *temp,*current;							//*current;
	Tree *mainroot;
	int a[10]={0,1,2,3,4,5,6,7,8,9};
	while(count<9){
			if(count==1){
			temp=new TreeNode(a[count]);
			mainroot=new Tree(temp);
			count++;
		}
		else{
		TreeNode * ret;
		temp=new TreeNode(a[count]);
		ret=mainroot->GetPar(count);
		ret->Locate(count,temp);
		count++;
		}
	
	}
		cout<<"finished!"<<endl;
		current=mainroot->GetRoot();
		mainroot->InOrder(leaf,current);
		cout<<leaf<<endl;
		current=mainroot->GetRoot();
		mainroot->DouOrder(current);
		mainroot->Tranvers(current);
}