#include<assert.h>
#include<iostream.h>
#include<string.h>
#include<stdio.h>

const int maxLen=128;//the maxmum length of a string

class String{//the definition of string class
public:
	String(const String & ob);//copy a string 
	String(const char *init);//construct a string 
	String();//emptied string
	~String(){delete[]ch;}
	int Length()const{return curLen;}
	String & operator()(int pos,int len);//get a substring
	int operator==(const String &ob)const{return strcmp(ch,ob.ch)==0;}
	int operator!=(const String &ob)const{return strcmp(ch,ob.ch)!=0;}
	int operator!()const{return curLen==0;}
	String & operator=(const String & ob);//get a string value from anothe string
	String &operator +=(const String &ob);//conjoin string
	char &operator[](int i);
	void disply(){cout<<ch<<endl;}
    void fail();//for the match of string ,to fast finding
	int fastFind(char *chpat);
	int fastFind(String & pat);//find a substring from the grandstring
private:
	int curLen;
	char *ch;
	int *f;
};

String::String(const String & ob){
	ch=new char[maxLen+1];
	assert(ch);
	curLen=ob.curLen;
	strcpy(ch,ob.ch);
}
String::String(const char *init){
	ch=new char[maxLen+1];
	assert(ch);
	curLen=strlen(init);
	strcpy(ch,init);
}
String::String(){
	ch=new char[maxLen+1];
	assert(ch);
	curLen=0;
	ch[0]='\0';
}
String & String::operator()(int pos,int len){
	String *temp=new String;
	if(pos<0||pos+len-1>=maxLen||len<0){
		temp->curLen=0;temp->ch[0]='\0';
	}
	else{
		if(pos+len-1>=curLen)len=curLen-pos;
		temp->curLen=len;
		for(int i=0,j=pos;i<len;i++,j++)temp->ch[i]=ch[j];
		temp->ch[len]='\0';
	}
	return *temp;
}
String & String::operator=(const String &ob){
	if(&ob!=this){
		delete[]ch;
		ch=new char[maxLen+1];
		assert(ch);
		curLen=ob.curLen;
		strcpy(ch,ob.ch);
	}
	else cout<<"Attempted assignment of a String to itself!\n";
	return *this;
}
String & String::operator+=(const String & ob){
	curLen+=ob.curLen;
	if(curLen>=maxLen){cout<<"too long to conjoin"<<endl;}
	strcat(ch,ob.ch);
	return *this;
}
char &String::operator[](int i){
	if(i<0&&i>=curLen){cout<<"Out of Boundary!\n";}
	return ch[i];
}
int String::fastFind(String &pat){
	int posP=0,posT=0;
    int lengthP=pat.curLen,lengthT=curLen;
	pat.f=new int[pat.curLen];
	pat.fail();
	while(posP<lengthP&&posT<lengthT)
		if(pat.ch[posP]==ch[posT]){
			posP++,posT++;
		}
		else if(posP==0)posT++;
		     else posP=pat.f[posP-1]+1;
    if(posP<lengthP)return -1;
	else return posT-lengthP;
	delete []pat.f;
}
int String::fastFind(char *chpat){
	int posP=0,posT=0;
	String pat(chpat);
    int lengthP=pat.curLen,lengthT=curLen;
	pat.f=new int[pat.curLen];
	pat.fail();
	while(posP<lengthP&&posT<lengthT)
		if(pat.ch[posP]==ch[posT]){
			posP++,posT++;
		}
		else if(posP==0)posT++;
		     else posP=pat.f[posP-1]+1;
    if(posP<lengthP)return -1;
	else return posT-lengthP;
	delete []pat.f;
	delete []pat.ch;
}
void String::fail(){
	int lengthP=curLen;
	f[0]=-1;
	for(int j=1;j<lengthP;j++){
		int i=f[j-1];
		while(*(ch+j)!=*(ch+i+1)&&i>=0)i=f[i];
		if(*(ch+j)==*(ch+i+1))f[j]=i+1;
		else f[j]=-1;
	}
}
//here is the homework,the string replacement
int Replace(String &s,String &t,String &v){//String replace operator
	int i,j=0;
	String temp1;//string temp1 as the new string after replaced
	String temp2=s;//string temp2 as the transition
    i=temp2.fastFind(t);//find the first location
    while(i!=-1){
		temp1+=temp2(0,i);//copy the unreplaced part of temp2 to temp1
	    if(temp1.Length()+v.Length()<maxLen)temp1+=v;//add the replaced string to temp1
	    else {cout<<"too long to replace";return 0;}//failure
	    j=i+t.Length();//ignore the replaced part of temp2
	    temp2=temp2(j,s.Length());//continue to match string in the rear part
		i=temp2.fastFind(t);//match
	}
	temp1+=temp2(0,temp2.Length());
	s=temp1;//copy the new string to s
	return 1;//succeed
}
 
void main(void){
	//an example
	String S("I will always love you!");
	String A("But I don't love you.");
	String subt("love");
	String subv("hate");
	cout<<"The grand_string:";
	S.disply();
	cout<<"We replace 'love' with 'hate':";
	Replace(S,subt,subv);
	S.disply();
	S+=A;
	S.disply();
	Replace(S,subt,subv);
	S.disply();
	
	char s0[100],t0[20],v0[30];
	cout<<"\ninput string:"<<endl;
	gets(s0);//recive the string
	String s(s0);//construct the string object
	cout<<"input substring:"<<endl;
	gets(t0);//the substring
	String t(t0);
	cout<<"input replacestring:"<<endl;
	gets(v0);//replacestring
	String v(v0);
	Replace(s,t,v);//replace
	s.disply(); 
}
