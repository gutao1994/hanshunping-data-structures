#include<iostream.h>
#include<stdlib.h>
template<class Type>class Array{//class array
	public:
		Array(){};
		Array(int sz);
		Array(Type *x,int n);//establish the array with initlization
		void place(int i,Type item);//place item to certain location
		void disply();.//display the content of array
		Type & operator [](int i);//read certain element from the array
		Array<Type> & operator=(const Array<Type>&A);//array copy
		int Length()const{return ArraySize;};
		~Array(){delete [] elements;};
	private:
		Type *elements;
		int ArraySize;
		void getArray();
};

template<class Type>void Array<Type>::getArray(){
	elements=new Type[ArraySize];
	if(elements==0)cerr<<"Memory Allocation Error"<<endl;
}
template<class Type>Array<Type>::Array(int sz){
	if(sz<=0){cerr<<"Invalid Array size"<<endl;exit(1);}
	ArraySize=sz;
	getArray();
	return;
}
template<class Type>Array<Type>::Array(Type *x,int n){
	ArraySize=n;
	elements=new Type[n];

	if(elements==0)cerr<<"Memory Allocation Error"<<endl;
	Type *srcptr=x;
	Type *destptr=elements;
	while(n--)*destptr++=*srcptr++;
	return;
}
template<class Type>Type & Array<Type>::operator[](int i){
	if(i<0||i>ArraySize-1)cerr<<"Index out of Range"<<endl;
	return elements[i];
}
template<class Type>void Array<Type>::disply(){
	for(int i=0;i<ArraySize;i++)cout<<elements[i]<<" ";
	cout<<endl;
}

template<class Type>Array<Type> & Array<Type>::operator=(const Array<Type>&A){
	int n=ArraySize=A.ArraySize;
	delete[]elements;
	elements=new Type[n];

	if(elements==0){cerr<<"Memory Allocation Error"<<endl;exit(1);}
	Type *srcptr=A.elements;
	Type *destptr=elements;
	while(n--)*destptr++=*srcptr++;
	return *this;
}
template<class Type>void Array<Type>::place(int i,Type item){
	if(i<0||i>ArraySize-1)cout<<"Invalid Index range"<<endl;
	elements[i]=item;
}
//the Josephus problem
void Josephus(int n,int s,int m){
	Array<int>A(n);
	for(int i=0;i<n;i++)A.place(i,i+1);

	int k,c=s-1;
	for(i=0;i<n-1;i++){
		c=(c+m-1)%(n-i);//calculat the location of next
		k=A[c];
		for(int j=c;j<n-1-i;j++)A.place(j,A[j+1]);
		A[n-1-i]=k;//place the out data to the rear of the array
	}
	Array<int>B(n);
	for(i=0;i<n;i++)B.place(i,A[n-i-1]);
	B.disply();
}

		
void main(void){
	cout<<"Josephus n=9,s=1,m=5: ";Josephus(9,1,5);
	cout<<"Josephus n=9,s=1,m=10: ";Josephus(9,1,10);
}