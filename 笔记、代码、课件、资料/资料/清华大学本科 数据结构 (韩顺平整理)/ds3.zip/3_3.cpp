#include<iostream.h>
template<class Type>class List;
template<class Type>class ListNode{//the node class definition
    friend class List<Type>;//set list class as friend
    public:
	    ListNode();
	    ListNode(const Type & item);//get a node with data item
	    ListNode<Type>*NextNode(){return link;}//get next node of this
	    void InsertAfter(ListNode<Type>*p);//insert a node here
	    ListNode<Type>*RemoveAfter();//remove a node
		void disply(){cout<<data;}//display the data of this node
    private:
	    Type data;//the data field
	    ListNode<Type>*link;//the pointer of next node
};
template<class Type>class List{//list class definition
	public:
		List(){last=first=new ListNode<Type>;last->link=NULL;}//emptied initilized list
		~List();
		void MakeEmpty();//empty a list
		int Length()const;//get the list length
        ListNode<Type>*GetNode(const Type & item,ListNode<Type>*next);
		ListNode<Type> * Find(int i);//find a node by number
        ListNode<Type> * Findv(Type value);//find a node by value
		int Insert(Type value,int i);//insert a node of data 'value' at location 'i'
		void Append(Type value);//add a node at the end
		Type Remove(int i);//remove the i node,return it's value
		Type *Get(int i);//get the value of the i node
		ListNode<Type>*First(){return first;}//get the head of list
        void conjoin(List<Type> &ha,List<Type> &hb);//conjoin two list to  one
		void disply();//display the data of a list
	private:
		ListNode<Type>*first,*last;
};
template<class Type>ListNode<Type>::ListNode():link(NULL){}
template<class Type>ListNode<Type>::ListNode(const Type & item):data(item),link(NULL){}
template<class Type>void ListNode<Type>::InsertAfter(ListNode<Type>*p){
	p->link=link;link=p;
}
template<class Type>ListNode<Type>*List  <Type>::GetNode(const Type & item,ListNode<Type>*next){
	ListNode<Type>*newnode=new ListNode<Type>;
	newnode->data=item;
	newnode->link=next;
	return newnode;
}
template<class Type>ListNode<Type>*ListNode<Type>::RemoveAfter(){
	ListNode<Type>*tempptr=link;
	if(link==NULL)return NULL;
	link=tempptr=link;
	retukrn tempptr;
}
template<class Type>List<Type>::~List(){
	MakeEmpty();delete first;first=last=NULL;
}
template<class Type>void List<Type>::MakeEmpty(){
	ListNode<Type>*q;
	while(first->link!=NULL){
		q=first->link;first->link=q->link;
		delete q;
	}
	last=first;
}
template<class Type>int List<Type>::Length()const{
	ListNode<Type>*p=first->link;
	int count=0;
	while(p!=NULL){p=p->link;count++;}
	return count;
}
template<class Type>ListNode<Type>*List<Type>::Findv(Type value){
	ListNode<Type>*p=first->link;
	while(p!=NULL&&p->data!=value)p=p->link;
	return p;
}
template<class Type>ListNode<Type> * List<Type>::Find(int i){
	if(i<=-1)return NULL;
	if(i==0)return first;
	ListNode<Type>*p=first->link;
	int j=0;
	while(p!=NULL&&j<i){p=p->link;j++;}
	return p;
}
template<class Type>int List<Type>::Insert(Type value,int i){
	ListNode<Type>*p=Find(i-1);
	if(p==NULL)return 0;
	ListNode<Type>*newnode;
	newnode=GetNode(value,p->link);
	if(p->link==NULL)last=newnode;
	p->link=newnode;
	return 1;
}
template<class Type>void List<Type>::Append(Type value){
	last->link=new ListNode<Type>;
	last=last->link;
	last->data=value;
	last->link=NULL;
}
template<class Type>Type List<Type>::Remove(int i){
	ListNode<Type>*p=Find(i-1),*q;
	if(p==NULL||p->link==NULL)return NULL;
	q=p->link;p->link=q->link;
	Type value=q->data;
	if(q==last)last=p;
	delete q;
	return value;
}
template<class Type>Type* List<Type>::Get(int i){
	ListNode<Type>*p=Find(i);
	if(p==NULL||p==first)return NULL;
	else return &p->data;
}
template<class Type>void List<Type>::disply(){
	ListNode<Type> *p;
	p=first->link;
	while(p!=NULL){p->disply();cout<<" ";p=p->link;}
	cout<<endl;
}
//here is the homework,conjoin two anti-descended sequential list to one 
//anti-ascended sequential list
template<class Type>void List<Type>::conjoin(List<Type> &ha,List<Type> &hb){
	ListNode<Type>*p=ha.First()->link,*q=hb.First()->link,*s,*t;
	//get the heads of both the lists,one by pointer 'p',another by 'q'
	ha.last=ha.first;
	ha.last->link=NULL;
	hb.last=hb.first;
	hb.last->link=NULL;//set the two lists empty
    this->MakeEmpty();//set the local list empty
    if(p->data<q->data){t=p;last=p;p=p->link;s=p;}//the minimum node as list-end
	else{t=q;last=q;q=q->link;}
	t->link=NULL;//local list-end
	while(p!=NULL&&q!=NULL){//get the node from the two list one by one
		if(p->data<q->data){s=p;p=p->link;s->link=t;t=s;}
		else {s=q;q=q->link;s->link=t;t=s;}
		//link each to the local list
	}
    if(p==NULL){//link the q-pointer list to local list directy
		s=q;
		while(s!=NULL){s=s->link;q->link=t;t=q;q=s;}
	}
	else{//link the p-pointer list to local list directly
		s=p;
		while(s!=NULL){s=s->link;p->link=t;t=p;q=p;}

	}
	first->link=t;//set the local list' head
}
void main(){
	List<int> l,m,h;
	int array[10]={2,2,6,8,9,10,11,11,12,15};
    int another[10]={0,2,3,4,4,6,14,24,59,78};
    for(int i=0;i<10;i++){
		l.Append(array[i]);//establish a list with 2,2,6,8,9,10,11,11,12,15
		m.Append(another[i]);//establist a list wity 0,2,3,4,4,6,14,24,59,78
	}
	l.disply();
	m.disply();
	h.conjoin(l,m);//conjoin list l and m to h
	h.disply();
}
	