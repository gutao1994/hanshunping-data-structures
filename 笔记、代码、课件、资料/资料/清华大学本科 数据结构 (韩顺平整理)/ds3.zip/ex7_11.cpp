#include "ex7_11.h"
void main(){
	dataList<int> mylist;
	cin>>mylist;
	cout<<mylist;
	int key;
	char ch;
	cout<<"input '1' for search\t'0' for end:";
	cin>>ch;
	while(ch=='1'){
		cout<<"input the search key:";
		cin>>key;
		if(mylist.Search(key)==1)
			cout<<"the element is found,";
		else 
			cout<<"the element is not found,";
		cout<<mylist;
		cout<<"input '1' for search\t'0' for end:";
		cin>>ch;
	}
}
