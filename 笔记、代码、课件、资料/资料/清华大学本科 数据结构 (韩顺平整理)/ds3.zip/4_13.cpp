#include<iostream.h>
#include<assert.h>
enum Boolean{FRONT,REAR};//Bool variable,FRONT:enter queue from front,REAR:from rear
template<class Type>class DQueue;
template<class Type>class DQueueNode{//the node class definition
	friend class DQueue<Type>;
	private:
		Type data;
		DQueueNode<Type>*link;
		DQueueNode(Type d=0,DQueueNode*l=NULL):data(d),link(l){}
};
template<class Type>class DQueue{
	public:
		DQueue():rear(NULL),front(NULL){}
		~DQueue(){MakeEmpty();}
		void EnDQueue(const Type&item,Boolean k);//enter queue,k designate enter-direction
		Type DeDQueue();//delete a node from the queue,of cause,from front
		Type GetFront();//get the data of front node
		void MakeEmpty();
		int IsEmpty()const{return front==NULL;}//judge wether has it emptied
	private:
		DQueueNode<Type>*front,*rear;
};
template<class Type>void DQueue<Type>::MakeEmpty(){
	DQueueNode<Type>*p;
	while(front!=NULL){
		p=front;front=front->link;delete p;
	}
	rear=NULL;
}
//here is the homework,a queue admit of enter from both the direction,
//but one direction remove
template<class Type>void DQueue<Type>::EnDQueue(const Type&item,Boolean k){
	DQueueNode<Type>*p=new DQueueNode<Type>(item,NULL);
	if(IsEmpty())front=rear=p;
	else if(k==FRONT){p->link=front;front=p;}//enter from front
	else{rear->link=p;rear=p;}//enter from rear
}
template<class Type>Type DQueue<Type>::DeDQueue(){//delete only from front
	assert(!IsEmpty());
	DQueueNode<Type>*p=front;
	Type value=p->data;
	front=front->link;delete p;
	return value;
}
template<class Type>Type DQueue<Type>::GetFront(){
	assert(!IsEmpty());
	return front->data;
}
void main()
{
	char array[10]="abcdefghi";
	DQueue<char> dqueue;
	cout<<"We enter the queue with 'a' 'b' 'c' from the front,"<<endl;
	for(int i=0;i<3;i++)//enter queue from front
		dqueue.EnDQueue(array[i],FRONT);
	cout<<"Now the front node is :"<<dqueue.GetFront()<<endl;
	cout<<"We enter the queue with 'd' 'e' 'f' 'g' from the rear,"<<endl;
	for(i=3;i<7;i++)//enter queue from rear 
		dqueue.EnDQueue(array[i],REAR);
	cout<<"Finally we delete seven node:\n";
	for(i=0;i<7;i++)
		cout<<dqueue.DeDQueue()<<" ";
	cout<<endl;
	if(dqueue.IsEmpty())cout<<"the queue has been emptied!\n";//judge empty
}
		
