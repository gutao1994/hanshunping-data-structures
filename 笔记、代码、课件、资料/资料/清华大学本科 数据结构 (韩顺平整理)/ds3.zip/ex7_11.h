#include <iostream.h>
template<class Type> class dataList;
template<class Type> class dataNode{
	Type key;
	dataNode<Type> *left,*right;
public:
	dataNode(const Type &value=0):key(value),left(NULL),right(NULL){}
	Type getKey(){return key;}
	void setKey(Type k){key=k;}
	dataNode<Type> *leftNode(){return left;}
	dataNode<Type> *rightNode(){return right;}
	friend class dataList<Type>;
};
template<class Type> class dataList{
	dataNode<Type> *head,*current;
public:
	dataList(){head=new dataNode<Type>();current=head;}
	~dataList();
	int Search(const Type &key);
	void InsMem(const Type &key);
	friend istream& operator>>(istream& in,dataList<Type> &inlist);
	friend ostream& operator<<(ostream& out,const dataList<Type> &outlist);
};
template<class Type> dataList<Type>::~dataList(){
	dataNode<Type> *tmp;
	current=head->right;
	while(current!=NULL){
		tmp=current;
		current=current->right;
		delete tmp;
	}delete head;
}
template<class Type> int dataList<Type>::Search(const Type &key){
	cout<<"the searching route:";
	if(current->key<key)
		while(current!=NULL&&current->key<key){
			cout<<current->key<<"  ";
			current=current->right;
		}
	else if(current->key>key)
		while(current!=head&&current->key>key){
			cout<<current->key<<"  ";
			current=current->left;
		}
	if(current==NULL||current==head){
			cout<<endl;
			current=head->right;
			return 0;
	}
	if(current->key==key){
		cout<<current->key<<endl;
		return 1;
	}else {
		cout<<current->key<<endl;
		return 0;
	}
}
template<class Type> void dataList<Type>::InsMem(const Type &key){
	dataNode<Type> *ptr;
	current=head;
	while((ptr=current->right)!=NULL && ptr->key<key) current=current->right;
	if(ptr==NULL){
		current->right=ptr=new dataNode<Type>(key);
		ptr->left=current;
		current=ptr;
	}else if(ptr->key==key) 
		cout<<"member with key="<<key<<" has existed"<<endl;
		else{
			ptr->left=current->right=new dataNode<Type>(key);
			current->right->right=ptr;
			current->right->left=current;
			current=ptr;
		}
}
template<class Type> istream& operator>>(istream& in,dataList<Type> &inlist){
	Type key;
	cout<<"input the data(end with -1):";
	in>>key;
	while(key!=-1){
		inlist.InsMem(key);
		cout<<"input the data(end with -1):";
		in>>key;
	}return in;
}
template<class Type> ostream& operator<<(ostream& out,const dataList<Type> &outlist){
	out<<"the datalist:"<<endl;
	dataNode<Type> *ptr=outlist.head->rightNode();
	while(ptr!=NULL){
		out<<ptr->getKey();
		if(outlist.current==ptr) out<<"(current)";
		out<<"  ";
		ptr=ptr->rightNode();
	}out<<endl;
	return out;
}
