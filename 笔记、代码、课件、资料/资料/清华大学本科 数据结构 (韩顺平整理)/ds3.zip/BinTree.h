#include <iostream.h>

template<class Type> class BinTree;
template<class Type> class BinTreeNode{
	friend class BinTree<Type>;
	public:
		BinTreeNode():leftChild(NULL),rightChild(NULL){}
		BinTreeNode(Type item):data(item),leftChild(NULL),rightChild(NULL){}
		BinTreeNode(Type item,BinTreeNode<Type> *le,BinTreeNode<Type> *ri):\
			        data(item),leftChild(le),rightChild(ri){}
		Type &GetData()const{return data;}
		BinTreeNode<Type> *GetLeft()const{return leftChild;}
		BinTreeNode<Type> *GetRight()const{return rightChild;}
		void SetData(const Type& item){data=item;}
		void SetLeft(BinTreeNode<Type> *L){ leftChild=L;}
		void SetRight(BinTreeNode<Type> *R){ rightChild=R;}
	private:
		Type data;
		BinTreeNode<Type> *leftChild,*rightChild;
};

template<class Type> class BinTree{
	public:
		BinTree():root(NULL){}
 		BinTree(Type value):RefValue(value),root(NULL){}
		virtual ~BinTree(){destroy(root);}

		virtual int IsEmpty()
			{return root==NULL?1:0;}
		virtual BinTreeNode<Type> *Parent(BinTreeNode<Type> *current)
			{return root==NULL||root==current?NULL:Parent(root,current);}
		virtual BinTreeNode<Type> *leftChild(BinTreeNode<Type> *current)
			{return root!=NULL?current->leftChild:NULL;}
		virtual BinTreeNode<Type> *RighttChild(BinTreeNode<Type> *current)
			{return root!=NULL?current->rightChild:NULL;}
		
		int Insert(const Type& item);
		int Find(const Type& item);
		BinTreeNode<Type> *GetRoot()const{return root;}
		void SetUpTree(BinTreeNode<Type> *current,Type *T,int i);
/*	
		int CreatTree(int n);		
		void DoubleOrder();
		void InOrder();
		void PreOrder();
		void PostOrder();
*/
//		virtual int LeafNum(BinTreeNode<Type> *current);
//		virtual int ChangeChild(BinTreeNode<Type> *current);
	
    
		friend istream &operator>>(istream &in,BinTree<Type> &Tree);
		friend ostream &operator<<(ostream &out,BinTree<Type> &Tree);

	private:
		BinTreeNode<Type> *root;          
		Type RefValue;

		BinTreeNode<Type> *Parent(BinTreeNode<Type> *start,BinTreeNode<Type> *current);
	
		
		int  Insert(BinTreeNode<Type> *current,const Type &item);
		void Traverse(BinTreeNode<Type> *current,ostream &out)const;
		int  Find(BinTreeNode<Type> *current,const Type &item) const;
		
/*		int  LeafNum(BinTreeNode<Type> *current);
		int  ChangeChild(BinTreeNode<Type> *current);*/
    	void destroy(BinTreeNode<Type> *current);

};






