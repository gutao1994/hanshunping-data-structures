#include <iostream.h>
#include "BinTree.cpp"

void main()
{
	BinTree<char> Tree;
    BinTreeNode<char> *cur=new BinTreeNode<char>;
	int i,l;
	char TA[30];
	cout<<"Please input the complete binary tree Arrary LENGTH:";
	cin>>l;
	TA[0]=l;
	cout<<"Please input the complete binary tree Arrary:"<<endl;
	for(i=1;i<=l;i++) cin>>TA[i];
	Tree.SetUpTree(cur,TA,1);
	cout<<Tree;
}