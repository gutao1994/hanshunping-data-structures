//calculate n!*2^n,the result is placed in A[arraySize],located n
#include<iostream.h>
const int maxInt=1000000000;
const int arraySize=10;
int cal(int n,long int A[])
{
	int k=1;
	if(n==0){A[0]=1;return 1;}
	else if(n>0&&n<=arraySize)
	{
		for(int i=1;i<=n;i++)
		{
			if(maxInt/k<=i)return 0;//too large,can't be contained	
		    k=k*2*i;//calcalate 
		}
		A[n]=k;
		return 1;
	}
	else return 0;//n<0 or n>arraySize,out of the range
}

void main()
{
	long int A[arraySize];
	int n;
	cout<<"Please input n:";
    cin>>n;
	if(cal(n,A))cout<<"\nn="<<n<<","<<"A[n]=n!*2^n="<<A[n]<<endl;
	else cout<<"\nabnormal return!\n";//if get return 0,abnormal
}