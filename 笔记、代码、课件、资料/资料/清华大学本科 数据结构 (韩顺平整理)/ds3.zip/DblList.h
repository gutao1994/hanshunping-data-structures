#include <iostream.h>
template <class Type> class DblList;
template <class Type> class DblNode{
	Type data;
	DblNode<Type> *lLink,*rLink;
	DblNode(Type value=0,DblNode<Type> *left=NULL,DblNode<Type> *right=NULL):data(value),lLink(left),rLink(right){};
public:
	DblNode<Type> *getLeft(){return lLink;}
	DblNode<Type> *getRight(){return rLink;}
	Type getData(){return data;}
	friend class DblList<Type>;
};
template <class Type> class DblList{
	DblNode<Type> *first,*current;
public:
	DblList(Type uniqueVal=-1);
	~DblList();
	int Length() const;
	int IsEmpty() const {return first->rLink==first;}
	int Find(const Type &target);
	Type getData() const{return current->getData();}
	void Firster(){current=first;}
	int First();
	int Next();
	int Prior();
	int currValid(){return current !=NULL;}
	void Insert(const Type &value);
	void Remove();
	friend istream& operator>>(istream &in,DblList<Type> &dblist);
	friend ostream& operator<<(ostream &out,const DblList<Type> &dblist);
};
template<class Type> DblList<Type>::DblList(Type uniqueVal=-1){
	first=new DblNode<Type>(uniqueVal);
	first->rLink=first->lLink=first;current=NULL;
}
template<class Type> DblList<Type>::~DblList(){
	current=first->rLink;
	while(current!=NULL)
		Remove();
	delete current;
}
template<class Type> int DblList<Type>::Length()const{
	DblNode<type> *p=first->rLink;
	int count=0;
	while(p!=first){p=p->rLink;count++;}
	return count;
}
template<class Type> int DblList<Type>::Find(const Type &target){
	DblNode<Type> *p=first->rLink;
	while(p!=first&&p->data!=target) p=p->rLink;
	if(p!=first){
		current=p;return 1;
	}return 0;
}
template<class Type> int DblList<Type>::First(){
	if(!IsEmpty()){
		current=first->rLink;
		return 1;
	}current=NULL;
	return 0;
}
template<class Type> int DblList<Type>::Next(){
	if(current->rLink==first){
		current=NULL;
		return 0;
	}current=current->rLink;
	return 1;
}
template<class Type> int DblList<Type>::Prior(){
	if(current->lLink==first){
		current=NULL;
		return 0;
	}current=current->lLink;
	return 1;
}
template<class Type> void DblList<Type>::Insert(const Type &value){
	if(current==NULL)
		current=first->rLink=new DblNode<Type>(value,first,first);
	else{
		current->rLink=new DblNode<Type>(value,current,current->rLink);
		current=current->rLink;
	}current->rLink->lLink=current;
}
template<class Type> void DblList<Type>::Remove(){
	if(current!=NULL){
		DblNode<Type> *temp=current;
		current=current->lLink;
		current->rLink=temp->rLink;
		temp->rLink->lLink=current; delete temp;
		if(current==first)
			if(IsEmpty()) current=NULL;
			else current=current->lLink;
	}
}
template<class Type> istream& operator>>(istream &in,DblList<Type> &dblist){
	Type tmp;
	cout<<"input the data"<<endl;
	cout<<"at the beginning all freq=0"<<endl;
	in>>tmp;
	while (tmp.IsValid()){
		if(dblist.Find(tmp)!=1)
			dblist.Insert(tmp);
		else{
			cout<<"the item has been in the list"<<endl;
		}in>>tmp;
	}
	return in;
}

template<class Type> ostream& operator<<(ostream &out,const DblList<Type> &dblist){
	if(dblist.IsEmpty()) out<<"the dblist is empty"<<endl;
	else{
		DblNode<Type> *p=dblist.first->getRight();
		while(p!=dblist.first){
			out<<p->getData()<<"  ";
			p=p->getRight();
		}out<<endl;
	}return out;
}
