#include "BinaryTree.h"
void main(){
	BinaryTree<int> btree(-1);
	cin>>btree;
	cout<<btree;
	btree.DouOrder(btree.GetRoot());
}