#include <assert.h>
template <class Type> class Queue;
template <class Type> class myQueue;
template <class Type> class QueueNode{
	Type data;
	QueueNode<Type> *link;
	QueueNode(Type d=0,QueueNode *next =NULL):data(d),link(next){}
friend class Queue<Type>;
friend class myQueue<Type>;
};

template <class Type> class Queue{
	QueueNode<Type> *front,*rear;
public:
	Queue():rear(NULL),front(NULL){}
	~Queue();
	void EnQueue(const Type &item);
	Type DeQueue();
	Type GetFront();
	void MakeEmpty(){front=rear=NULL;}
	int IsEmpty()const{return front==NULL;}
};

template <class Type> Queue<Type>::~Queue(){
	QueueNode<Type> *p=front;
	while (front!=NULL){
		p=front;front=front->link;delete p;
	}
}
template <class Type> void Queue<Type>::EnQueue(const Type &item){
	if (front==NULL) front=rear=new QueueNode<Type>(item,NULL);
	else rear=rear->link=new QueueNode<Type>(item,NULL);
}
template <class Type> Type Queue<Type>::DeQueue(){
	assert(!IsEmpty());
	QueueNode<Type> *p=front;
	Type retvalue=p->data;
	front=front->link; delete p;
	return retvalue;
}
template <class Type> Type Queue<Type>::GetFront(){
	assert (!IsEmpty());
	return front->data;
}

