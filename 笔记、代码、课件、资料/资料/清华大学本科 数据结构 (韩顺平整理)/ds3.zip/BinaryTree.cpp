// BinaryTree<char>.cpp: implementation of the BinaryTree<char> class.
//
//////////////////////////////////////////////////////////////////////

#include "BinaryTree.h"
#include "math.h"
#include "iostream.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
void BinTreeNode::operator =(BinTreeNode *Right){
		data=Right->GetData();
		leftChild=Right->GetLeft();
		rightChild=Right->GetRight();
	}

void BinaryTree::destroy(BinTreeNode *current){
	if(current!=NULL){
		destroy(current->leftChild);
		destroy(current->rightChild);
		delete current;
    }
}

BinTreeNode*BinaryTree::Parent(BinTreeNode*start,BinTreeNode*current){
	if(start==NULL)return NULL;
	if(start->leftChild==current||start->rightChild==current)return start;
	BinTreeNode *p;
	if((p=Parent(start->leftChild,current))!=NULL)return p;
	else return Parent(start->rightChild,current);
}

void BinaryTree::Traverse(BinTreeNode*current,ostream&out)const{
	if(current!=NULL){
		out<<current->data<<' ';
		Traverse(current->leftChild,out);
		Traverse(current->rightChild,out);
	}
}

void BinaryTree::Construct(char*arr,int n){
	BinTreeNode *temp;
	BinTreeNode *loc[128];
	int current=0;
	int level=0,cout=0;
	for(current=0;current<n;current++){		
		temp=new BinTreeNode(arr[current]);
		loc[current]=temp;
		
	}
	current=0;
	while(current<n&&(2*current+1)<n){
		loc[current]->leftChild=loc[2*current+1];
		if(2*current+2<n)
			loc[current]->rightChild=loc[2*current+2];
		current++;
	}
    root=loc[0];
}

void BinaryTree::BldBst(BinTreeNode*root,char *arr,int n,float*p,float*q){

}
void main()
{
	BinaryTree MyTree;
    char T[128];
	int size;
	cout<<"Input your binary tree size:";
	cin>>size;
	cout<<"Input your binary tree members:"<<endl;
	for(int i=0;i<size;i++){
		cin>>T[i];
	}
	MyTree.Construct(T,size);
}