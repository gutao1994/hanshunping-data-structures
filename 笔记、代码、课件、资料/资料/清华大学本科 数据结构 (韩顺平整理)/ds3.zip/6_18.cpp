#include<iostream.h>
#include<stdio.h>
#include<stdlib.h>
template<class Type>class BinaryTree;
template<class Type>class BinTreeNode{
	friend class BinaryTree<Type>;
	public:
		BinTreeNode():leftChild(NULL),rightChild(NULL){}
		BinTreeNode(Type item,BinTreeNode<Type>*left=NULL,
			BinTreeNode<Type>*right=NULL):data(item),
			leftChild(left),rightChild(right){}
		Type&GetData(){return data;}
		BinTreeNode<Type>*GetLeft()const{return leftChild;}
        BinTreeNode<Type>*GetRight()const{return rightChild;}
        void SetData(const Type&item){data=item;}
		void SetLeft(BinTreeNode<Type>*L){leftChild=L;}
		void SetRight(BinTreeNode<Type>*R){rightChild=R;}
	private:
		BinTreeNode<Type>*leftChild,*rightChild;
		Type data;
};
template<class Type>class BinaryTree{
	public:
		BinaryTree():root(NULL){}
		BinaryTree(Type value):RefValue(value),root(NULL){}
		virtual ~BinaryTree(){destroy(root);}
		virtual int IsEmpty(){return root==NULL?1:0;}
		virtual BinTreeNode<Type>*Parent(BinTreeNode<Type>*current){
			return root==NULL||root==current?NULL:Parent(root,current);}
        virtual BinTreeNode<Type>*LeftChild(BinTreeNode<Type>*current){
			return root!=NULL?current->leftChild:NULL;}
		virtual BinTreeNode<Type>*RightChild(BinTreeNode<Type>*current){
			return root!=NULL?current->rightChild:NULL;}
		virtual void Insert(const Type&item){PreInsert(root,item);}
		//virtual int Find(const Type&item)const;
		const BinTreeNode<Type>*GetRoot()const{return root;}
		void DbOrderTravs(){DbOrderTravs(root);}
		friend istream&operator>>(istream&in,BinaryTree<Type>&Tree);
		friend ostream&operator<<(ostream&out,BinaryTree<Type>&Tree);
	private:
		BinTreeNode<Type>*root;
		Type RefValue;

		BinTreeNode<Type>*Parent(BinTreeNode<Type>*start,BinTreeNode<Type>*current);
		void PreInsert(BinTreeNode<Type>*&current,const Type&item);
		void Traverse(BinTreeNode<Type>*current,ostream&out)const;
		void DbOrderTravs(BinTreeNode<Type>*current);
		int Find(BinTreeNode<Type>*current,const Type&item)const;
		void destroy(BinTreeNode<Type>*current);
};
template<class Type>void BinaryTree<Type>::destroy(BinTreeNode<Type>*current){
	if(current!=NULL){
		destroy(current->leftChild);
		destroy(current->rightChild);
		delete current;
	}
}
template<class Type>BinTreeNode<Type>*BinaryTree<Type>::
Parent(BinTreeNode<Type>*start,BinTreeNode<Type>*current){
	if(start==NULL)return NULL;
	if(start->leftChild==current||start->rightChild==current)return start;
	BinTreeNode<Type>*p;
	if((p=Parent(start->leftChild,current))!=NULL)return p;
	else return Parent(start->rightChild,current);
}
template<class Type>void BinaryTree<Type>::PreInsert(BinTreeNode<Type>*&current,const Type&item){
	if(current==NULL){
		current=new BinTreeNode<Type>(item,NULL,NULL);
		if(current==NULL){cerr<<"Out of space"<<endl;exit(1);}
	}
	else if(item>current->data)PreInsert(current->rightChild,item);
	else PreInsert(current->leftChild,item); 
}
template<class Type>void BinaryTree<Type>::Traverse(BinTreeNode<Type>*current,ostream
													&out)const{
	if(current!=NULL){
		Traverse(current->leftChild,out);
		out<<current->data<<' ';
		Traverse(current->rightChild,out);
	}
}
template<class Type>istream&operator>>(istream&in,BinaryTree<Type>&Tree){
	Type item;
	cout<<"Construct to produce a binary sorting tree:\n";
	cout<<"Input data(end with '"<<Tree.RefValue<<"'):";
	in>>item;
	while(item!=Tree.RefValue){
		Tree.Insert(item);
		cout<<"Input data(end with '"<<Tree.RefValue<<"'):";
		in>>item;
	}
	return in;
}
template<class Type>ostream&operator<<(ostream&out,BinaryTree<Type>&Tree){
	out<<"Inorder trversal of binary tree.\n";
	Tree.Traverse(Tree.root,out);
	out<<endl;
	return out;
}
//here is the homework,double order traversal
template<class Type>void BinaryTree<Type>::DbOrderTravs(BinTreeNode<Type>*current){
	if(current!=NULL){
		cout<<current->data<<" ";//visit current node data
		DbOrderTravs(current->leftChild);//traversal left subtree
		DbOrderTravs(current->rightChild);//traversal right subtree
        cout<<current->data<<" ";//visit current node data again
	}
}
void main()
{
	BinaryTree<char>Tree('!');
	cin>>Tree;
	cout<<endl<<endl<<Tree<<endl;
	Tree.DbOrderTravs(); 
	cout<<endl;
}
  