#include<iostream.h>
int maxmum(int *A,int n){//recurve maxmum
	if(n<=1)return A[0];//only one element,return it directly
	else return A[n-1]>=maxmum(A,n-1)?A[n-1]:maxmum(A,n-1);//recurve
}
int sum(int *A,int n){//recurve sum;
	if(n<=1)return A[0];//only one element,return it directly
	else return A[n-1]+sum(A,n-1);//recurve
}
double average(int *A,int n){//cecurve average 
	if(n<=1)return (double)A[0];//only one element,return it directly
	else return (double)(((double)A[n-1]+average(A,n-1)*(n-1))/n);//recurve
}
void main(){
	int A[10]={199,3,444,54,54,64,3,245,9,39};//array definition
	cout<<"A[10]={199,3,444,54,54,64,3,245,9,39}"<<endl;
	cout<<"the maxmum is:"<<maxmum(A,10)<<endl;//maxmum
	cout<<"the sum is:"<<sum(A,10)<<endl;//sum
	cout<<"the average is:"<<average(A,10)<<endl;//average
}
