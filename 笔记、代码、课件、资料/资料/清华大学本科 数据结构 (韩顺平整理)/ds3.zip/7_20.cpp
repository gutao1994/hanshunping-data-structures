#include <iostream.h>
#include <math.h>

const int Max=5;
int R[Max][Max],W[Max][Max];
void FindRoot(int l,int h){
	if(l<h){
		R[l][h]=l;
		int min=abs(W[l-1][l-1]-W[l][h]);
		int value;
		for(int i=l+1;i<=h;i++){
			value=abs(W[l-1][i-1]-W[i][h]);
			if(min>value){
				min=value;
				R[l][h]=i;
			}
		}
		FindRoot(l,R[l][h]-1);//recurve left 
		FindRoot(R[l][h]+1,h);//recurve right
	}
	else R[l][h]=0;
}
template<class Type> void OpticBST(int p[],int q[],Type a[],const int n){
	for(int i=0;i<n+1;i++)
		for(int j=i;j<n+1;j++)//initilize the W[i][j]
			if(i==j) W[i][j]=q[i];
			else W[i][j]=W[i][j-1]+p[j]+q[j];
	FindRoot(1,n);//construct the tree 
}
void main(){
	int p[5]={0,5,20,10,5},q[5]={20,10,20,5,5};
	char *a[4]={"else","public","return","template"};
	OpticBST(p,q,a,4);
	
	int i,j;
	cout<<"W\t";
    for(i=0;i<Max;i++)cout<<i<<"\t";
	cout<<endl;
	for(i=0;i<Max;i++){
		cout<<i<<"\t";
		for(int j=0;j<Max;j++)
			if(i>j)cout<<"\t";
			else cout<<W[i][j]<<"\t";
		cout<<endl;
	}
	cout<<"\nR\t";
	for(i=0;i<Max;i++)cout<<i<<"\t";
	cout<<endl;
	for(i=0;i<Max;i++){
	    cout<<i<<"\t";
		for(j=0;j<Max;j++)
			cout<<R[i][j]<<"\t";
		cout<<endl;
	}
}
	