#include<iostream.h>
template<class Type>class DblList;
template<class Type>class DblNode{//double direct list node class
	friend class DblList<Type>;
	private:
		Type data;//data field
		int freq;//visit frequency
		DblNode<Type> *lLink,*rLink;//link pointer
	public:
		DblNode(Type value,DblNode<Type> *left,DblNode *right):data(value),freq(0),lLink(left),rLink(right){}
        DblNode(Type value):data(value),lLink(NULL),rLink(NULL){}
};
template<class Type>class DblList{//double direct list class definition
	public:
		DblList(Type uniqueVal);
		~DblList();
		void MakeEmpty();//set empty
		int Length()const;//get the length
		int IsEmpty(){return first->rLink==first;}//wether is it empty
		int Find(const Type&target);//find an element
		Type GetData()const;//return current data
		void Firster(){current=first;}
		DblNode<Type>*Current(){return current;}//get current pointer
		int First();//put the pointer to the first 
		int Next();//pointer moves to next location
		int Prior();//pointer moves to  prior location
		int operator!(){return current!=NULL;}
		void Insert(const Type&value);//Insert node with value 
		void Locate();//set the current node visiting frequency
		void Locate(int i);//set the i location node visition frequency
		void Locate(Type x);//find element x,set it's visiting frequency
		Type Remove();//remove a node
	private:
		DblNode<Type>*first,*current;
};
template<class Type>void DblList<Type>::MakeEmpty(){
		while(current!=NULL)Remove();
}
template<class Type>DblList<Type>::~DblList(){MakeEmpty();delete first;}
template<class Type>DblList<Type>::DblList(Type uniqueVal){
	first=new DblNode<Type>(uniqueVal);
	first->rLink=first->lLink=first;
	current=NULL;
}
template<class Type>int DblList<Type>::Length()const{
	DblNode<Type>*p=first->rLink;
	int count=0;
	while(p!=first){p=p->rLink;count++;}
	return count;
}
template<class Type>int DblList<Type>::Find(const Type &target){
	int count=1;
	DblNode<Type>*p=first->rLink;
	while(p!=first&&p->data!=target){p=p->rLink;count++;}
	if(p!=first){current=p;return count;}
	return 0;
}
template<class Type>Type DblList<Type>::GetData()const{
	int a;
	if(first->rLink==first){
		cout<<"no data in list,illegal operate\npress 0 and ENTER\n";
		cin>>a;
		return NULL;
	}
	else return current->data;
}
template<class Type>int DblList<Type>::First(){
	if(!IsEmpty()){current=first->rLink;return 1;}
	current=NULL;return 0;
}
template<class Type>int DblList<Type>::Next(){
	if(IsEmpty()){return 0;}
	current=current->rLink;
	if(current==first)current=first->rLink;
	return 1;
}
template<class Type>int DblList<Type>::Prior(){
	if(IsEmpty){return 0;}
	current=current->lLink; 
	if(current==first)current=first->lLink;
	return 1;
}
template<class Type>void DblList<Type>::Insert(const Type &value){
	if(current==NULL)
		current=first->rLink=new DblNode<Type>(value,first,first);
	else{
		current->rLink=new DblNode<Type>(value,current,current->rLink);
		current=current->rLink;
	}
	current->rLink->lLink=current;
}
template<class Type>Type DblList<Type>::Remove(){
	Type value;
	if(current!=NULL){
		DblNode<Type> *temp=current;
		current=current->rLink;
		current->lLink=temp->lLink;
		temp->lLink->rLink=current;
		value=temp->data;
		delete temp;
		if(current==first)
			if(IsEmpty())current=NULL;
			else current=current->rLink;
	}
	return value;
}
//here is the homework,location accord as visiting frequency
template<class Type>void DblList<Type>::Locate(){//current node
	if(!IsEmpty()){
		DblNode<Type>*temp=current;
		temp->freq++;//visiting frequency is added 1 to itself
		First();
		while(current->freq>=temp->freq)current=current->rLink;
		//find the suitable location of the node
		//move the node to its location
		temp->rLink->lLink=temp->lLink;
		temp->lLink->rLink=temp->rLink;
		temp->rLink=current;
		temp->lLink=current->lLink;
		current->lLink->rLink=temp;
		current->lLink=temp;
		current=temp;
	}
	else{cout<<"Is a emptied list !";}
}
template<class Type>void DblList<Type>::Locate(int i){
	if(i<=Length()){
		int j=1;
		First();
		while(j++<i)current=current->rLink;
		//find its location and locate it
		Locate();
	}
	else{cout<<"Is a emptied list or location too far!";}
}
template<class Type>void DblList<Type>::Locate(Type x){
	Find(x);//find the element's location
	Locate();//locate it
}
template<class Type>void Locate(DblList<Type>&L,Type x){
	//this function doesn't belong a class
	L.Find(x);
	L.Locate();
}
void main()
{
	DblList<char> dlist('A');
	char array[11]="abcdefghij";
	for(int i=0;i<10;i++)
		dlist.Insert(array[i]);
	cout<<"Construct the DList with element 'a b c d e f g h i j'";
	dlist.First();
	dlist.Locate(3);//visiting the third node,it is 'c'
	dlist.First();
	cout<<endl<<"Visit 'c',display 7 node:"<<endl;
    for(i=0;i<7;i++){//we can find it has been moved to the front
        cout<<dlist.GetData()<<" ";
		dlist.Next();
	}
    cout<<endl;
    Locate(dlist,'d');//visiting the node of 'd',
	dlist.First();
	cout<<"Visit 'd',display 7 node:"<<endl;
    for(i=0;i<7;i++){//we can find it has been moved to the front,behind 'c'
        cout<<dlist.GetData()<<" ";
		dlist.Next();
	}
    cout<<endl;
    dlist.First();
	dlist.Locate('g');//visiting 'g' twice
	dlist.Locate('g');
	dlist.First();	
	cout<<"Visit 'g' twice,display 7 node:"<<endl;
	for(i=0;i<7;i++){//we can find it has gone to the head location
        cout<<dlist.GetData()<<" ";
		dlist.Next();
	}
	cout<<endl;
}


