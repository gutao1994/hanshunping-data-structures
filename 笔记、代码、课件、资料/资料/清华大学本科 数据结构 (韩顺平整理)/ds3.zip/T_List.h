#include <iostream.h>
#include <stdlib.h> 

template <class Type> class List;

template <class Type> class ListNode{
friend class List<Type>;
public:
	ListNode();
	ListNode(Type &item);
	ListNode<Type> *NextNode(){return link;}
	void InsertAfter(ListNode<Type> *p);
	ListNode<Type> *GetTheNode(const Type &item);
	ListNode<Type> *RemoveAfter();
private:
	Type data;
	ListNode<Type> *link;
};

template <class Type> class List{
public:
	List(){last=first=new ListNode<Type>;}
	List(Type value){last=first=new ListNode<Type>(value);}
	~List();
	void MakeEmpty();
	int Length() const;
	ListNode<Type> *vFind(Type value);
	ListNode<Type> *iFind(int i);
	int Insert(Type value,int i);
	Type *Remove(int i);
    Type Get(int i);
	void TMerge(List<Type> &listb);
private:
	ListNode<Type> *first,*last;
};

