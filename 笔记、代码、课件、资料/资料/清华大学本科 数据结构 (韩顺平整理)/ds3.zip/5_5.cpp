#include<iostream.h>
class ListHerit;
template<class Type>class List;
template<class Type>class ListNode{//the node class definition
    friend class List<Type>;//set list class as friend
	friend class ListHerit;
    public:
	    ListNode();
	    ListNode(const Type & item);//get a node with data item
	    ListNode<Type>*NextNode(){return link;}//get next node of this
	    void InsertAfter(ListNode<Type>*p);//insert a node here
	    ListNode<Type>*RemoveAfter();//remove a node
		void disply(){cout<<data;}//display the data of this node
    private:
	    Type data;//the data field
	    ListNode<Type>*link;//the pointer of next node
};
template<class Type>class List{//list class definition
	public:
		List(){last=first=new ListNode<Type>;last->link=NULL;}//emptied initilized list
		~List();
		void MakeEmpty();//empty a list
		int Length()const;//get the list length
        ListNode<Type>*GetNode(const Type & item,ListNode<Type>*next);
		ListNode<Type> * Find(int i);//find a node by number
        ListNode<Type> * Findv(Type value);//find a node by value
		int Insert(Type value,int i);//insert a node of data 'value' at location 'i'
		void Append(Type value);//add a node at the end
		Type Remove(int i);//remove the i node,return it's value
		Type *Get(int i);//get the value of the i node
		ListNode<Type>*First(){return first;}//get the head of list
        void disply();//display the data of a list
	protected:
		ListNode<Type>*first,*last;
};
template<class Type>ListNode<Type>::ListNode():link(NULL){}
template<class Type>ListNode<Type>::ListNode(const Type & item):data(item),link(NULL){}
template<class Type>void ListNode<Type>::InsertAfter(ListNode<Type>*p){
	p->link=link;link=p;
}
template<class Type>ListNode<Type>*List  <Type>::GetNode(const Type & item,ListNode<Type>*next){
	ListNode<Type>*newnode=new ListNode<Type>;
	newnode->data=item;
	newnode->link=next;
	return newnode;
}
template<class Type>ListNode<Type>*ListNode<Type>::RemoveAfter(){
	ListNode<Type>*tempptr=link;
	if(link==NULL)return NULL;
	link=tempptr=link;
	retukrn tempptr;
}
template<class Type>List<Type>::~List(){
	MakeEmpty();delete first;first=last=NULL;
}
template<class Type>void List<Type>::MakeEmpty(){
	ListNode<Type>*q;
	while(first->link!=NULL){
		q=first->link;first->link=q->link;
		delete q;
	}
	last=first;
}
template<class Type>int List<Type>::Length()const{
	ListNode<Type>*p=first->link;
	int count=0;
	while(p!=NULL){p=p->link;count++;}
	return count;
}
template<class Type>ListNode<Type>*List<Type>::Findv(Type value){
	ListNode<Type>*p=first->link;
	while(p!=NULL&&p->data!=value)p=p->link;
	return p;
}
template<class Type>ListNode<Type> * List<Type>::Find(int i){
	if(i<=-1)return NULL;
	if(i==0)return first;
	ListNode<Type>*p=first->link;
	int j=0;
	while(p!=NULL&&j<i){p=p->link;j++;}
	return p;
}
template<class Type>int List<Type>::Insert(Type value,int i){
	ListNode<Type>*p=Find(i-1);
	if(p==NULL)return 0;
	ListNode<Type>*newnode;
	newnode=GetNode(value,p->link);
	if(p->link==NULL)last=newnode;
	p->link=newnode;
	return 1;
}
template<class Type>void List<Type>::Append(Type value){
	last->link=new ListNode<Type>;
	last=last->link;
	last->data=value;
	last->link=NULL;
}
template<class Type>Type List<Type>::Remove(int i){
	ListNode<Type>*p=Find(i-1),*q;
	if(p==NULL||p->link==NULL)return NULL;
	q=p->link;p->link=q->link;
	Type value=q->data;
	if(q==last)last=p;
	delete q;
	return value;
}
template<class Type>Type* List<Type>::Get(int i){
	ListNode<Type>*p=Find(i);
	if(p==NULL||p==first)return NULL;
	else return &p->data;
}
template<class Type>void List<Type>::disply(){
	ListNode<Type> *p;
	p=first->link;
	while(p!=NULL){p->disply();cout<<" ";p=p->link;}
	cout<<endl;
}
//here is the homework,recurve maxmum,sum,average of a list of int
class ListHerit:public List<int>{
    private:
		int maxmum(ListNode<int>*p);//recurve maxmum
		int sum(ListNode<int>*p);//recurve sum
		double average(ListNode<int>*p);//recurve average
		int curlen(ListNode<int>*p);//get the length from p-pointer to the end
	public:
		int Maxmum(){return maxmum(first->link);}
		int Sum(){return sum(first->link);}
		double Average(){return average(first->link);}
};
int ListHerit::maxmum(ListNode<int>*p){//recurve maxmum
	if(p==last)return p->data;//if only one element,return its data
	else return p->data>=maxmum(p->link)?p->data:maxmum(p->link);//recurve
}
int ListHerit::sum(ListNode<int>*p){//recurve sum
	if(p==last)return p->data;//if only one element,return its data
	else return p->data+sum(p->link);//recurve
}
double ListHerit::average(ListNode<int>*p){//recurve average
	if(p==last)return (double)p->data;//if only one element,return its data
	else return (double)(((double)p->data+\
		average(p->link)*curlen(p->link))/curlen(p));//recurve
}
int ListHerit::curlen(ListNode<int>*p){
	int count=0;
	while(p!=NULL){count++;p=p->link;}
	return count;
}
void main(){
	ListHerit l,m;
	int array[10]={2,2,6,8,9,10,11,11,12,15};
    for(int i=0;i<10;i++){
		l.Append(array[i]);//establish a list with 2,2,6,8,9,10,11,11,12,15
		}
	cout<<"We have established a list with 2,2,6,8,9,10,11,11,12,15.\n";
	cout<<"output the list:\n";
	l.disply();
	cout<<endl<<"The maxmum is:"<<l.Maxmum();
	cout<<endl<<"The sum is:"<<l.Sum();
	cout<<endl<<"The average is:"<<l.Average()<<endl;

	cout<<"\nYou can input several numbers,end with -1:\n";
	int value;
	cin>>value;
	while(value!=-1){m.Append(value);cin>>value;}//as input,as establish
    cout<<"output the list:\n";
	m.disply();
	cout<<endl<<"The maxmum is:"<<m.Maxmum();
	cout<<endl<<"The sum is:"<<m.Sum();
	cout<<endl<<"The average is:"<<m.Average()<<endl;
}
	