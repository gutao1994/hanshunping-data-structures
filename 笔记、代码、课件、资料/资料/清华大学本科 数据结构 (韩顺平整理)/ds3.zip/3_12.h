#include "DblList.h"
class myData{
	char ch;
	int freq;
public:
	myData():ch(EOF),freq(0){}
	~myData(){}
	myData(char c,int fq=0):ch(c),freq(fq){}
//	myData(char c):ch(c),freq(1){}
	char getch(){return ch;}
	int getfq(){return freq;}
	void setfq(int fq){freq=fq;}
	int IsValid(){return ch!=EOF && freq!=-1;}
	int operator!=(const myData &item){return item.ch!=ch;}
	friend istream& operator>>(istream& in,myData &item);
	friend ostream& operator<<(ostream& out,const myData &item);
};
istream& operator>>(istream& in,myData &item){
	cout<<"input the char: ";
	cin>>item.ch;
//	cout<<"input the freq(end with -1):";
//	cin>>item.freq;
	return in;
}
ostream& operator<<(ostream& out,const myData &item){
	out<<item.ch<<"("<<item.freq<<")  ";
	return out;
}